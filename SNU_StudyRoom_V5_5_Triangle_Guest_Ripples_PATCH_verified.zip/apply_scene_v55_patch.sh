#!/usr/bin/env bash
set -euo pipefail
BASE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT="${STUDYROOM_PROJECT_DIR:-/workspaces/studycafe/SNU_3D_StudyRoom_v5_3_postgresql}"

if [[ ! -f "$PROJECT/index.html" || ! -f "$PROJECT/server/room.js" || ! -f "$PROJECT/package.json" ]]; then
  echo "ERROR: 스터디카페 프로젝트 폴더를 찾을 수 없습니다: $PROJECT" >&2; exit 1; fi

check_hash(){ local path="$1" expected="$2" actual; actual="$(sha256sum "$PROJECT/$path" | cut -d' ' -f1)"; if [[ "$actual" != "$expected" ]]; then echo "SAFETY_STOP: 다른 버전/수정 파일을 발견했습니다: $path" >&2; echo "파일을 덮어쓰지 않았습니다. 현재 V5.4 버전에 맞춰 다시 패치해야 합니다." >&2; exit 2; fi; }

# Check clean success before exact V5.4 baseline validation.
if [[ "$(sha256sum "$PROJECT/index.html" | cut -d' ' -f1)" == "e34dcdcc6e1066ec9f8672119da88b415edd4c10a111e4c0ace845bead656fbf" && "$(sha256sum "$PROJECT/server/room.js" | cut -d' ' -f1)" == "7ce5ca4e750ffb0f236d0d12973172c0e1df5c74c3c649062e7c77145cd76560" && -f "$PROJECT/tests/scene-v55.test.js" ]]; then
 echo "SCENE_V55_ALREADY_APPLIED: V5.5 코드를 이미 적용했습니다."; exit 0; fi
check_hash "index.html" "6fa11781bf6f449a12e7518d517652cbd2fbd7e4654d60883b391964a212c97b"
check_hash "server/room.js" "d8865533ed3cb3239b34f848d4dd1b869d17d5eb96580cd615051b381e3fd67d"
check_hash "client/friends.js" "2071facdc491c170bb727b7079b0b666535e3d545241ed8ac2f24962fb079aeb"
check_hash "tests/scene-v51.test.js" "c05ae3898a8397f4263ee2c1488cd319fe64448522f8352f0021b63bc0910781"
check_hash "tests/multiplayer.test.js" "4cce63e1ed8f85781ba903049cfd4e792adf71663876229f3ee3998fbcc4aedc"
check_hash "tests/v4-api.test.js" "c3966f9baa777dc60009f71c1caa10b854896eed083b4436861d6d66b1eb8d0e"
check_hash "package.json" "7d3b9ca7ddc5d3da50df272b2f0c00e3d623f9b4be8fbf134c8967e7f06b1320"

if [[ -e "$PROJECT/tests/scene-v55.test.js" ]]; then echo "SAFETY_STOP: tests/scene-v55.test.js가 이미 존재합니다." >&2; exit 2; fi
BACKUP="${STUDYROOM_SCENE_BACKUP_ROOT:-/home/codespace/.config/snu-studyroom}/scene-pre-v55-$(date -u +%Y%m%dT%H%M%SZ)"
mkdir -p "$BACKUP"
for file in \
  "index.html" \
  "server/room.js" \
  "client/friends.js" \
  "tests/scene-v51.test.js" \
  "tests/multiplayer.test.js" \
  "tests/v4-api.test.js" \
  "package.json"; do
 mkdir -p "$BACKUP/$(dirname "$file")"
 cp "$PROJECT/$file" "$BACKUP/$file"
done
restore_original(){
 for file in \
  "index.html" \
  "server/room.js" \
  "client/friends.js" \
  "tests/scene-v51.test.js" \
  "tests/multiplayer.test.js" \
  "tests/v4-api.test.js" \
  "package.json"; do
  cp "$BACKUP/$file" "$PROJECT/$file"
 done
 rm -f "$PROJECT/tests/scene-v55.test.js"
}

# Copy only the vetted files; never replace .env, secrets, PostgreSQL or backup config.
for file in \
  "index.html" \
  "server/room.js" \
  "client/friends.js" \
  "tests/scene-v51.test.js" \
  "tests/multiplayer.test.js" \
  "tests/v4-api.test.js" \
  "package.json" \
  "tests/scene-v55.test.js"; do
 mkdir -p "$PROJECT/$(dirname "$file")"
 cp "$BASE/payload/$file" "$PROJECT/$file"
done

if (cd "$PROJECT" && npm run check > "$BACKUP/check.log" 2>&1 && npm test > "$BACKUP/test.log" 2>&1); then
 echo "SCENE_V55_PATCH_OK: triangular supports, compact room, floor/chair ripples, guest-first onboarding, friends Google login."
 echo "SOURCE_BACKUP: $BACKUP"
 tail -n 12 "$BACKUP/test.log"
 echo "운영 Railway 서버는 아직 배포하지 않았습니다."
else
 restore_original
 echo "SCENE_V55_PATCH_FAILED: 검사 실패, V5.4 원본으로 복원했습니다." >&2
 tail -n 45 "$BACKUP/test.log" 2>/dev/null || tail -n 45 "$BACKUP/check.log" >&2 || true
 exit 3
fi
