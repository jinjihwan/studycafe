# 스터디카페 V5.5 패치 — 모바일 GitHub → Codespaces

이 파일은 **운영 중인 V5.4 PostgreSQL 프로젝트를 V5.5로 변경**하는 코드 패치입니다.

## 반영한 요청

- 공간 폭 54→48, 길이 98→88, 높이 18.6→16.2로 약 10~13% 축소
- 양측의 대각 X 교차 기둥을 **삼각형(∧/A 프레임)의 실제 사선 철골**로 변경. 원본 열람실 참고 사진처럼 대각선 빔 두 개가 상부에서 만나는 형태
- 책상 8개 × 6석 = 48석, NPC 8석 / 이용자 40석 유지
- 바닥을 탭할 때 해당 월드 좌표에 2중 확산 링 파형 표시(이동에 실패해도 클릭 위치 확인 가능)
- 의자 탭/좌석 예약 파형을 **접근용 이동 좌표가 아니라 해당 의자 좌판 중앙**으로 이동
- 첫 방문 시 계정 선택 화면 없이 캐릭터·닉네임 설정만 표시하고, 완료 시 게스트 접속. 설정 전 새로고침해도 설정창 유지
- 기존 접속자는 저장된 캐릭터 정보를 유지; 기존 Google 로그인 계정도 자동 로그아웃하지 않음
- 게스트가 `친구` 또는 `친구 랭킹`에 접근하면 `Google 로그인하고 친구 기능 사용` 버튼 제공
- 서버/클라이언트의 좌석·장애물·이동 경계 동기화

## 설치 순서 (GitHub를 통한 ZIP 전송)

1. 이 ZIP 자체를 `https://github.com/jinjihwan/studycafe`에 **Add file → Upload files → Commit changes**로 업로드합니다.
2. Codespaces 터미널에서 실행합니다.

```bash
cd /workspaces/studycafe
git pull --ff-only
mkdir -p /home/codespace/scene-v55-patch
unzip -o SNU_StudyRoom_V5_5_Triangle_Guest_Ripples_PATCH.zip -d /home/codespace/scene-v55-patch
bash /home/codespace/scene-v55-patch/apply_scene_v55_patch.sh
```

정상적인 경우 `SCENE_V55_PATCH_OK`와 테스트 개수가 표시됩니다. 패치 대상 V5.4 버전이 다르면 **변경 사항을 보호하기 위해 설치를 중단**합니다. 코드 백업은 `/home/codespace/.config/snu-studyroom/scene-pre-v55-*`에 보관합니다.

3. 로컬에서 결과 확인 후, 코드만 GitHub에 커밋할 때는 다음 두 단계가 필요합니다(배포는 별도 확인 후 진행).

```bash
cd /workspaces/studycafe
git add -u -- SNU_3D_StudyRoom_v5_3_postgresql
git add -- SNU_3D_StudyRoom_v5_3_postgresql/tests/scene-v55.test.js
git commit -m "V5.5 compact triangle scene and guest-first UI"
```

`git push origin main`으로 GitHub에 게시하면 **Railway GitHub 자동 배포가 시작될 수 있습니다.** 스터디룸에 사람이 없는 시간에 진행하고 백업이 남아 있는지 확인하세요. V5.5는 DB 마이그레이션을 하지 않지만, 클라이언트/서버 좌석 좌표가 바뀌므로 접속 중인 이용자는 새로고침하는 것이 좋습니다.

## 테스트

`npm run check` 성공 / `npm test` 55개 중 54개 통과, 1개 건너뜀, 실패 0개. 건너뛴 검사는 실제 외부 PostgreSQL에 연결하는 테스트입니다. 실제 브라우저 렌더링과 Google 팝업은 최종 기기에서 별도로 확인해야 합니다.

## 중요

- `.env`, Firebase 계정키, R2 키, PostgreSQL 데이터와 Railway 환경변수는 이 패치에 포함되지 않으며 변경하지 않습니다.
- Google 로그인 시 기존 게스트 기록 병합 절차는 유지합니다.
- 현재 다른 패치가 적용돼 원본 해시가 다르면, 안전하게 중단합니다. 이때 억지로 덮어쓰지 마세요.
