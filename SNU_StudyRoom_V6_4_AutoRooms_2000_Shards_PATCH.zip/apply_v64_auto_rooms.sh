#!/usr/bin/env bash
# V6.4 install: atomic room admission, auto-room, stateless WS gateway + 5 worker-capable source.
set -euo pipefail
PACKAGE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT="${STUDYROOM_PROJECT_DIR:-/workspaces/studycafe/SNU_3D_StudyRoom_v5_3_postgresql}"
MODIFIED=("index.html" "client/network.js" "client/friends.js" "server/index.js" "server/room.js" "server/account-api.js" "package.json")
NEW=("server/room-routing.js" "server/ws-router.js" "server/live-presence.js" "tests/v64-auto-room-sharding.test.js" "tests/v64-websocket-proxy.test.js" "tests/v64-friends-cross-worker.test.js" "scripts/loadtest-v64.mjs")
FILES=("${MODIFIED[@]}" "${NEW[@]}")
stop(){ echo "SAFETY_STOP: $1" >&2; exit 2; }
[[ -f "$PROJECT/index.html" && -f "$PROJECT/server/room.js" ]] || stop "프로젝트 폴더를 찾지 못했습니다: $PROJECT"
complete=true
for file in "${FILES[@]}";do
 [[ -f "$PROJECT/$file" ]] && cmp -s "$PROJECT/$file" "$PACKAGE/payload/$file" || { complete=false;break; }
done
if [[ "$complete" == true ]];then
 echo 'V64_ALREADY_APPLIED: V6.4 패치가 이미 적용되어 있습니다.'
 exit 0
fi
for file in "${NEW[@]}";do [[ ! -e "$PROJECT/$file" ]] || stop "이미 같은 이름의 신규 파일이 있습니다: $file";done
check_base(){
 local file="$1" expected="$2" received
 [[ -f "$PROJECT/$file" ]] || stop "V6.3 원본 파일이 없습니다: $file"
 received="$(sha256sum "$PROJECT/$file" | cut -d' ' -f1)"
 [[ "$received" == "$expected" ]] || stop "V6.3 원본과 다른 코드입니다: $file (덮어쓰기 중단)"
}
check_base "index.html" "2542d9c7f04a3bd2c9100a6c5f4167adb17a33a286d06b441e5301fc157fbf8e"
check_base "client/network.js" "401886e7c9744fee6aa134fac2e1b5f195de4a12d6db79fcbb83a60c51d6dc79"
check_base "client/friends.js" "d45806a8ea846c536b642bb3417ed5fb30deeb287c41e2f8ae6743cefd68fdcf"
check_base "server/index.js" "bc454a7775a82d7ffd8d89102b16e146ddc4dbe62ce432ecf9e52c3f825d0a6e"
check_base "server/room.js" "7e650668c5865a507d8d2b1adfaea4013c3a1153146d4724d8bd8e53ef21d903"
check_base "server/account-api.js" "37c6f2b73c5a17bd48e4d361e6907e57c4569ca24ba5353a0d6dfbbfb4bb2ff9"
check_base "package.json" "3731d0d0ca4757e0a3ff68bdfbfe18b8994448d5968d4664879a5b5852248f28"
BACKUP_ROOT="${STUDYROOM_PATCH_BACKUP_ROOT:-/home/codespace/.config/snu-studyroom}"
BACKUP="$BACKUP_ROOT/scale-pre-v64-$(date -u +%Y%m%dT%H%M%SZ)-$$"
mkdir -p "$BACKUP"
chmod 700 "$BACKUP"
for file in "${MODIFIED[@]}";do mkdir -p "$BACKUP/$(dirname "$file")";cp "$PROJECT/$file" "$BACKUP/$file";done
changed=false
rollback(){
 if [[ "$changed" == true ]];then
   for file in "${MODIFIED[@]}";do cp "$BACKUP/$file" "$PROJECT/$file";done
   for file in "${NEW[@]}";do rm -f "$PROJECT/$file";done
   echo 'ROLLBACK_OK: 오류 발생으로 기존 V6.3 코드를 복원했습니다.' >&2
 fi
}
on_error(){ local status=$?;trap - ERR INT TERM;rollback;exit "$status";}
trap on_error ERR INT TERM
changed=true
for file in "${FILES[@]}";do
 mkdir -p "$(dirname "$PROJECT/$file")"
 cp "$PACKAGE/payload/$file" "$PROJECT/$file"
done
if (cd "$PROJECT" && npm run check > "$BACKUP/check.log" 2>&1 && npm test > "$BACKUP/test.log" 2>&1);then
 changed=false;trap - ERR INT TERM
 echo 'V64_AUTO_ROOMS_PATCH_OK: 자동 방 생성 + 입장 예약 + 5개 워커 분산형 WS 코드 적용 완료'
 echo "SOURCE_BACKUP: $BACKUP"
 tail -n 13 "$BACKUP/test.log"
 echo '주의: 이 시점에는 자동 방 생성 코드만 설치됩니다. 2,000명 분산 운영에는 Railway 워커 5개 및 게이트웨이 설정, 부하 테스트가 별도로 필요합니다.'
else
 echo 'V64_PATCH_TEST_FAILED: 자동 복구를 시작합니다.' >&2
 tail -n 45 "$BACKUP/test.log" 2>/dev/null || tail -n 45 "$BACKUP/check.log" >&2 || true
 false
fi
