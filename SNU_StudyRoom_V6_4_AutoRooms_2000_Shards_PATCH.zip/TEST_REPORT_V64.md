# V6.4 자동 방 생성 · WebSocket sharding 시험 보고서

- 소스 기준: 사용자 V6.3 NPC Server Sync 패치를 적용한 코드를 정확히 비교(SHA-256).
- `npm run check`: PASS (JS syntax, project assets, page modules).
- `npm test`: 88 tests, 87 passed, 0 failed, 1 skipped (`postgres-live`, 실제 DB 비접속).
- 테스트한 내용: 방 번호 1~100 및 10번 이후 렌더링, 서울대/고려대/연세대 배치, 1번방 NPC 8명, 추가방 NPC 0명, 40/48석, 2000석의 5개 worker 분배 계산, 자동 입장 예약의 중복 예방 mock, HTTP/WebSocket worker 프록시 업그레이드, 다른 워커의 친구 따라가기, 게스트 방 현황 접근, 기존 계정/공부시간/친구/로그인 회귀.
- 설치 스크립트는 원본 SHA 검증, 기존 파일 백업, 자동 테스트, 실패 시 롤백, 중복 적용 방지를 포함.
- **검증하지 못한 내용:** 실제 Railway 환경의 5워커/게이트웨이 사설 네트워크 및 HTTPS/WSS, 실제 PostgreSQL 경쟁 트랜잭션, 진짜 2,000명 장시간 연결·오류율·FPS·DB 처리량, 비용, 장애 복구.
- **운영 주의:** 단일 서버에는 자동 방 생성이 추가되지만 512 연결 상한은 유지됩니다. 다중 서버 운영은 별도 인프라 설정과 스테이징 부하 검증 후 활성화해야 합니다.
