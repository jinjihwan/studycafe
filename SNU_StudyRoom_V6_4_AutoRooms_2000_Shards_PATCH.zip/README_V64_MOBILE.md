# V6.4 자동 방 생성 · 2,000명 분산 확장 준비 (모바일 설치)

## 핵심 주의

- 패치 적용 즉시 **자동 방 생성**은 단일 서버에서도 동작합니다. 기존 `maxConnections=512`는 그대로입니다.
- **2,000명 동시 접속은 테스트로 검증한 수치가 아닙니다.** 다중 서버 설정 전에는 2,000명 수용이 불가능합니다.
- 운영 서버에 곧바로 5개 워커를 붙이지 마세요. **Railway Staging 환경에서 검증한 후 단계적으로 전환**하세요.
- V6.3 NPC 동기화 패치가 **이미 적용된 코드**에만 설치되며, 코드 내용이 다르면 `SAFETY_STOP`으로 중단합니다.
- PostgreSQL 데이터 및 R2 백업 서비스 설정은 이 패치에서 변경하지 않습니다. 새 서버용 PostgreSQL 테이블 두 개는 앱 실행 시 `CREATE TABLE IF NOT EXISTS`로 만들어집니다.

## 1. 휴대폰에서 GitHub에 ZIP 업로드

`SNU_StudyRoom_V6_4_AutoRooms_2000_Shards_PATCH.zip`을 다운로드해
`https://github.com/jinjihwan/studycafe` → Add file → Upload files → Commit changes로 업로드합니다.

## 2. Codespaces에서 패치 적용

```bash
cd /workspaces/studycafe
git pull --ff-only
mkdir -p /home/codespace/v64-auto-rooms
unzip -o SNU_StudyRoom_V6_4_AutoRooms_2000_Shards_PATCH.zip -d /home/codespace/v64-auto-rooms
bash /home/codespace/v64-auto-rooms/apply_v64_auto_rooms.sh
```

`V64_AUTO_ROOMS_PATCH_OK`와 테스트 통과가 나오는지 확인합니다. `SAFETY_STOP`, `ROLLBACK_OK`, 테스트 실패 시 **즉시 중단**합니다.

## 3. 수정 코드만 GitHub에 저장

```bash
cd /workspaces/studycafe
git add -- \
 SNU_3D_StudyRoom_v5_3_postgresql/index.html \
 SNU_3D_StudyRoom_v5_3_postgresql/client/network.js \
 SNU_3D_StudyRoom_v5_3_postgresql/client/friends.js \
 SNU_3D_StudyRoom_v5_3_postgresql/server/index.js \
 SNU_3D_StudyRoom_v5_3_postgresql/server/room.js \
 SNU_3D_StudyRoom_v5_3_postgresql/server/account-api.js \
 SNU_3D_StudyRoom_v5_3_postgresql/server/room-routing.js \
 SNU_3D_StudyRoom_v5_3_postgresql/server/ws-router.js \
 SNU_3D_StudyRoom_v5_3_postgresql/server/live-presence.js \
 SNU_3D_StudyRoom_v5_3_postgresql/package.json \
 SNU_3D_StudyRoom_v5_3_postgresql/tests/v64-auto-room-sharding.test.js \
 SNU_3D_StudyRoom_v5_3_postgresql/tests/v64-websocket-proxy.test.js \
 SNU_3D_StudyRoom_v5_3_postgresql/tests/v64-friends-cross-worker.test.js \
 SNU_3D_StudyRoom_v5_3_postgresql/scripts/loadtest-v64.mjs
git commit -m "V6.4 auto-create rooms and prepare 2k sharded workers"
git push origin main
```

GitHub에 푸시하면 기존 Railway 자동 배포가 시작될 수 있습니다. 현재 서버가 단일 서버이면 **자동 방 생성만** 활성화됩니다. 앱 URL `/?room=main&auto=1` 등의 경로를 통해 빈 방을 자동 배정받고, 만석일 때도 빈 방으로 안내합니다. `/?room=main-2` 처럼 직접 들어갈 수도 있습니다.

## 4. 현재 단일 Railway 서버에서 확인

```bash
cd /workspaces/studycafe/SNU_StudyRoom_PG_Backup_Worker
railway deployment list --service focused-benevolence --environment production
```

최신 배포 `SUCCESS`, `/health` JSON `ok:true` 여부, 대학 선택 → 방 배정, 친구 초대 링크, 공부 기록 저장을 확인하세요.

## 5. 별도 단계: 실제 다중 서버로 확장 (스테이징 필수)

대량 유입이 예상되어도 테스트 없이 운영에 붙이지 마세요. 초기 계획은 **게이트웨이 1대 + WebSocket 워커 5대 + 공통 PostgreSQL**입니다.

### Railway 환경

- Free/Trial의 서비스 수 제한 때문에 추가 워커용 **Hobby 또는 적정 유료 요금제** 및 비용 예산을 먼저 확인하세요. 워커 5개가 무료라는 뜻이 아닙니다.
- **Staging 환경**을 만들어 WebSocket 워커 `studyroom-worker-0`부터 `studyroom-worker-4`까지 각기 **독립 Railway 서비스**로 생성합니다. Railway 단순 Replicas 5개와는 다릅니다. 같은 GitHub 저장소의 `SNU_3D_StudyRoom_v5_3_postgresql`을 빌드합니다.
- 각 워커는 1개의 `studyroom-worker-N` 서비스, Root Directory 및 Dockerfile/Start Command를 원래 웹 앱과 똑같이 지정합니다. **Public Domain은 생성하지 않고 Railway 사설 네트워크만 사용**합니다.
- 각각 `NODE_ENV=production`, `HOST=::`, `PORT=3000`, `STUDYROOM_WORKER_COUNT=5`, `STUDYROOM_WORKER_INDEX=0..4` (서비스마다 한 숫자), `STUDYROOM_SERVER_MAX_CONNECTIONS=512`, `STUDYROOM_FLUSH_INTERVAL_MS=20000`으로 설정합니다.
- 5대 워커 및 게이트웨이에 동일한 **기존 `STUDYROOM_SECRET`**, 동일한 **새 `STUDYROOM_INTERNAL_SECRET` (길이 최소32자)**, `DATABASE_URL=${{Postgres.DATABASE_URL}}`, `STUDYROOM_PUBLIC_ORIGIN=https://focused-benevolence-production-db18.up.railway.app`와 기존 Firebase 인증 관련 변수들을 사용합니다. Staging에서는 해당 환경의 공개 도메인으로 바꿉니다. **새 비밀값을 채팅이나 GitHub에 게시하지 마세요.**
- `STUDYROOM_INTERNAL_SECRET`는 PostgreSQL DB 비밀번호나 백업 암호화 키를 재활용하지 않고 별도로 생성합니다. 예: `openssl rand -hex 32` (절대로 출력값을 채팅에 보내지 마세요).
- 워커가 각각 온라인 및 `GET /health` 응답 `ok:true`인 것을 확인합니다.
- **이후에만** 게이트웨이 서비스(`focused-benevolence`)에 `STUDYROOM_ROUTER_TARGETS`를 다음과 같이 설정합니다:

```text
http://studyroom-worker-0.railway.internal:3000,http://studyroom-worker-1.railway.internal:3000,http://studyroom-worker-2.railway.internal:3000,http://studyroom-worker-3.railway.internal:3000,http://studyroom-worker-4.railway.internal:3000
```

게이트웨이에는 `STUDYROOM_WORKER_COUNT`, `STUDYROOM_WORKER_INDEX`를 **설정하지 않습니다.** `STUDYROOM_ROUTER_MAX_CONNECTIONS=4096`, 동일한 `STUDYROOM_INTERNAL_SECRET`, PostgreSQL·Firebase·기존 앱 환경변수를 유지합니다.

**주의:** worker 서비스를 스테이징 환경에서 만들었다면 gateway도 같은 스테이징 환경이어야 private DNS에서 보입니다. 운영 gateway에 staging worker 주소를 넣지 마세요.

### 스테이징에서 기능 시험

1. 3개 대학 각각 1번 방 → 2번 방 자동 생성 및 전환 확인
2. 1번 방은 NPC 8명, 2번 방 이후 NPC 0명 / 48석 확인
3. 다른 서버에 배정된 방 간 이동과 친구 따라가기, 공부 시간 저장 확인
4. 구글 로그인·게스트→구글 전환 및 새로고침 중 복구 확인
5. 데이터베이스 손상 여부, CPU/RAM, 응답 지연, 연결률 확인

프로젝트의 테스트 스크립트는 **스테이징 주소에서 1~40명 소규모 테스트만 허용**합니다:

```bash
cd /workspaces/studycafe/SNU_3D_StudyRoom_v5_3_postgresql
node scripts/loadtest-v64.mjs --url=https://YOUR-STAGING-DOMAIN --users=20 --confirm-staging=yes
```

실제 **2,000명 성공 판정**에는 별도의 **분산 부하 발생기 + 2,000 WS 지속 연결 + 움직임/착석/재연결/DB 저장 시나리오**가 필요합니다. 5개 워커에 2,000명이 수학적으로 배정되더라도, Railway 네트워크/CPU/메모리, PostgreSQL 성능이 충분한지는 검증되지 않았습니다.

### 종료/복구

- 문제가 생기면 게이트웨이의 `STUDYROOM_ROUTER_TARGETS`를 해제해 단일 서버 모드로 되돌릴 수 있습니다. **하지만 2,000명 상황에서 이 모드로 되돌리면 연결 한도 문제가 재발할 수 있습니다.**
- 이전 버전으로 완전히 되돌릴 때는 `SOURCE_BACKUP` 경로의 V6.3 코드 및 배포 Git 커밋을 이용하세요. 자동 복구용 백업은 Codespaces 외부로도 안전하게 보관하는 것이 좋습니다.
