# V6.2 연세대학교 열람실 사진 기반 배치 개선

이 ZIP은 기존 **V6.1 세 도서관 프로젝트**에 적용되는 덮어쓰기-검증형 패치입니다.

## 변경 내용

- 연세대학교 방 **정면(-Z 방향) 책장/안내 데스크 삭제** → 높은 대형 창문, 창틀, 외부 나무/건물 풍경.
- 왼쪽: **원형 4인 책상 × 6 = 24석** (복수 사용자용 원형 컴퓨터 테이블과 사방 칸막이).
- 가운데: **왼쪽(-X)을 바라보는 1인 책상 × 8 = 8석**.
- 오른쪽: **양쪽이 서로 마주보는 2인 책상 × 8 = 16석**.
- 총 **22개 책상, 48개 의자** / NPC 8석, 게스트·계정 사용자 40석.
- 연세대 3종류 좌석에 맞춰 **방향(Yaw), 접근 좌표, 의자 선택, 착석/일어나기 좌표**를 브라우저와 서버에서 동일하게 수정했습니다.
- 서울대·고려대 방의 가구·좌석 배치, 로그인, 친구, 공부 기록 및 PostgreSQL 백업 설정은 변경하지 않습니다.

## 휴대폰 GitHub → Codespaces 적용

1. GitHub `jinjihwan/studycafe` 최상위에 `SNU_StudyRoom_V6_2_Yonsei_Photo_Layout_PATCH.zip` 업로드 및 Commit changes.
2. 기존 Codespaces 터미널에서 아래 명령을 순서대로 실행합니다.

```bash
cd /workspaces/studycafe
git pull --ff-only
mkdir -p /home/codespace/v62-yonsei-patch
unzip -o SNU_StudyRoom_V6_2_Yonsei_Photo_Layout_PATCH.zip -d /home/codespace/v62-yonsei-patch
bash /home/codespace/v62-yonsei-patch/apply_v62_yonsei_patch.sh
```

`V62_YONSEI_PATCH_OK` 확인 후:

```bash
cd /workspaces/studycafe
git add -- \
  SNU_3D_StudyRoom_v5_3_postgresql/index.html \
  SNU_3D_StudyRoom_v5_3_postgresql/server/room.js \
  SNU_3D_StudyRoom_v5_3_postgresql/package.json \
  SNU_3D_StudyRoom_v5_3_postgresql/tests/v61-three-libraries.test.js \
  SNU_3D_StudyRoom_v5_3_postgresql/tests/v62-yonsei-photo-layout.test.js
git commit -m "V6.2 rebuild Yonsei study room from reference photo"
git push origin main
```

Railway에 GitHub 자동배포가 연결되어 있으면 신규 배포가 시작될 수 있습니다. 확인:

```bash
cd /workspaces/studycafe/SNU_StudyRoom_PG_Backup_Worker
railway deployment list --service focused-benevolence --environment production
```

최신 배포가 `SUCCESS`일 때 공개 URL `https://focused-benevolence-production-db18.up.railway.app/?room=yonsei`를 새로고침해 확인합니다.

## 안전 및 검증

- 설치 스크립트는 기존 V6.1 핵심 4개 파일의 SHA256을 확인합니다. 원본이 조금이라도 다르면 `SAFETY_STOP`으로 중단합니다.
- 설치 전에 원본을 `/home/codespace/.config/snu-studyroom/scene-pre-v62-*/` 아래에 백업합니다.
- `npm run check`, `npm test` 실패 시 원래 V6.1 파일을 자동 복구합니다.
- 기존 데이터베이스 환경변수·암호화 키·백업 서비스 설정은 수정하지 않습니다.
- 설치를 반복 실행하면 `V62_ALREADY_APPLIED`를 출력합니다.
- GitHub에 평소와 달리 코드가 별도 편집되어 있으면 자동으로 덮어쓰지 않습니다.

## 참고

사용자가 제공한 연세·삼성학술정보관 실내 사진의 배치 패턴을 참고해 **3D 모델을 코드로 생성**했습니다. 실제 사진을 사이트에 삽입한 것은 아니며, 사진 밖의 치수·구조는 게임 동선에 맞춘 추정치입니다. 실제 기기 WebGL 성능 및 화면은 배포 후 추가 확인이 필요합니다.
