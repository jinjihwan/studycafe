# V6.2 테스트 보고

기준: V6.1 Three Libraries PATCH 적용본.

- 구현: 연세대 앞 벽 서가 제거, 전면 대형 창, 왼쪽 6개 원형(24석), 중앙 8개 1인석, 오른쪽 8개 2인석(16석).
- `npm run check`: 통과.
- `npm test` (`node --test --test-concurrency=2`): **67 tests / 66 pass / 0 fail / 1 skipped**.
- 스킵: 실제 PostgreSQL 연결을 요구하는 통합 테스트. 기존 시스템에서 동일하게 선택적으로 건너뜀.
- 신규 검사: 사진 구도(서가 없음), 좌석 배치·수·NPC, 모든 좌석 접근성 및 회전 방향, 실제 서버 seat_request/seat_sit/stand, 기존 3개 도서관 격리와 회귀 테스트.
- 아래에 별도로 패치의 적용/재적용/원본불일치 중단 스모크 테스트를 수행합니다.
- 실제 스마트폰에서의 렌더링/실서버 구글 로그인 및 Railway 배포는 로컬 테스트 범위 밖입니다.
