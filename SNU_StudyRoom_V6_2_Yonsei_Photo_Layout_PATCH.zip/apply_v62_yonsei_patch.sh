#!/usr/bin/env bash
# V6.2: reference-photo Yonsei atrium / 6 circular x4 + 8 single x1 + 8 pair x2.
# Install only on the exact tested V6.1 sources. Original db/server secret files untouched.
set -euo pipefail
BASE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT="${STUDYROOM_PROJECT_DIR:-/workspaces/studycafe/SNU_3D_StudyRoom_v5_3_postgresql}"
SOURCE_FILES=(index.html server/room.js package.json tests/v61-three-libraries.test.js)
NEW_FILE=tests/v62-yonsei-photo-layout.test.js
if [[ ! -f "$PROJECT/index.html" || ! -f "$PROJECT/server/room.js" ]];then
 echo "SAFETY_STOP: 스터디카페 코드 경로가 존재하지 않습니다: $PROJECT" >&2;exit 2
fi
if [[ -e "$PROJECT/$NEW_FILE" ]];then
 finished=true
 for file in "${SOURCE_FILES[@]}" "$NEW_FILE";do
  if [[ ! -f "$PROJECT/$file" ]] || ! cmp -s "$PROJECT/$file" "$BASE/payload/$file";then finished=false;break;fi
 done
 if [[ "$finished" == true ]];then
  echo 'V62_ALREADY_APPLIED: 연세대 V6.2가 이미 적용되어 있습니다.';exit 0
 fi
 echo 'SAFETY_STOP: V6.2 테스트 파일이 이미 존재하거나 기존 패치가 일부 변경되었습니다.' >&2;exit 2
fi
check(){ local rel="$1" expected="$2" got
 if [[ ! -f "$PROJECT/$rel" ]];then echo "SAFETY_STOP: 파일이 없습니다: $rel" >&2;exit 2;fi
 got="$(sha256sum "$PROJECT/$rel" | cut -d' ' -f1)"
 if [[ "$got" != "$expected" ]];then
  echo "SAFETY_STOP: V6.1 원본과 다릅니다: $rel" >&2
  echo '사용자 변경사항을 보호하려고 중단했습니다. 아무것도 덮어쓰지 않았습니다.' >&2
  exit 2
 fi
}
check index.html 0325c0f598e7e2cb0b11ee9f1f809b26e9f03ec8bb4dfdcbc1a30047194255dc
check server/room.js dedb464b224f0e478df8af3318e6af13b06884aa875bd7c6b7aed0a8eebc7167
check package.json 0580b45937bd10b6bef29ca02df5befc89a44bebcc7e61027ef8b5d7f03a5923
check tests/v61-three-libraries.test.js 3b5cd1ef7596f9280abd4abb5edc697b7d28cb24f83c6fc26b8d854b459e4fc0
BACKUP_ROOT="${STUDYROOM_SCENE_BACKUP_ROOT:-/home/codespace/.config/snu-studyroom}"
BACKUP="$BACKUP_ROOT/scene-pre-v62-$(date -u +%Y%m%dT%H%M%SZ)-$$"
mkdir -p "$BACKUP/server" "$BACKUP/tests"
chmod 700 "$BACKUP"
for rel in "${SOURCE_FILES[@]}";do cp "$PROJECT/$rel" "$BACKUP/$rel";done
changed=false
rollback(){
 if [[ "$changed" == true ]];then
  for rel in "${SOURCE_FILES[@]}";do cp "$BACKUP/$rel" "$PROJECT/$rel";done
  rm -f "$PROJECT/$NEW_FILE"
  echo 'ROLLBACK_OK: 기존 V6.1 소스로 복원했습니다.' >&2
 fi
}
on_error(){ local code=$?;trap - ERR INT TERM;rollback;exit "$code"; }
trap on_error ERR INT TERM
changed=true
for rel in "${SOURCE_FILES[@]}" "$NEW_FILE";do cp "$BASE/payload/$rel" "$PROJECT/$rel";done
if (cd "$PROJECT" && npm run check > "$BACKUP/check.log" 2>&1 && npm test > "$BACKUP/test.log" 2>&1);then
 changed=false;trap - ERR INT TERM
 echo 'V62_YONSEI_PATCH_OK: front windows; 6 round/8 single/8 pair desks; 48 seats.'
 echo "SOURCE_BACKUP: $BACKUP"
 tail -n 13 "$BACKUP/test.log"
 echo '코드 적용 완료. GitHub push 및 Railway 배포 전입니다.'
else
 echo 'V62_PATCH_FAILED: 테스트 실패. 기존 코드로 자동 복구합니다.' >&2
 tail -n 32 "$BACKUP/test.log" 2>/dev/null || tail -n 32 "$BACKUP/check.log" >&2 || true
 false
fi
