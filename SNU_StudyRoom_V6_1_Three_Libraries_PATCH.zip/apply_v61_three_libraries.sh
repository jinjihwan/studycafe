#!/usr/bin/env bash
# V6.1: Yonsei room / KU user-visible rename / SNU rotated independent braces.
# Apply only to the exact, tested V6.0 studyroom files; never touch database secrets.
set -euo pipefail
BASE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT="${STUDYROOM_PROJECT_DIR:-/workspaces/studycafe/SNU_3D_StudyRoom_v5_3_postgresql}"
SOURCE_FILES=(
 index.html server/room.js package.json
 tests/v6-korea-library.test.js tests/scene-v51.test.js tests/scene-v55.test.js
)
NEW_FILE=tests/v61-three-libraries.test.js
if [[ ! -f "$PROJECT/index.html" || ! -f "$PROJECT/server/room.js" ]]; then
 echo "SAFETY_STOP: 프로젝트 경로가 올바르지 않습니다: $PROJECT" >&2;exit 2
fi
sha(){ sha256sum "$PROJECT/$1" | cut -d' ' -f1; }
if [[ -f "$PROJECT/$NEW_FILE" ]]; then
 # All included files must match; do not mistake partial/mixed installations for success.
 finished=true
 for file in "${SOURCE_FILES[@]}" "$NEW_FILE";do
  if [[ ! -f "$PROJECT/$file" ]] || ! cmp -s "$PROJECT/$file" "$BASE/payload/$file"; then finished=false;break;fi
 done
 if [[ "$finished" == true ]];then echo 'V61_ALREADY_APPLIED: 3개 도서관 코드가 이미 적용되어 있습니다.';exit 0;fi
 echo 'SAFETY_STOP: V6.1 파일이 일부만 존재하거나 변경되었습니다. 파일을 덮어쓰지 않습니다.' >&2;exit 2
fi
check(){ local file="$1" expected="$2" got
 if [[ ! -f "$PROJECT/$file" ]];then echo "SAFETY_STOP: 기존 파일이 없습니다: $file" >&2;exit 2;fi
 got="$(sha "$file")"
 if [[ "$got" != "$expected" ]];then
  echo "SAFETY_STOP: 기존 V6.0 버전이 일치하지 않습니다: $file" >&2
  echo '데이터를 삭제하거나 코드를 덮어쓰지 않았습니다. 최신 버전을 확인하세요.' >&2;exit 2
 fi
}
check index.html 5db5e52a09385aeecdfbdfec5a840101ed635d5044d5e34dac0432af77349ee7
check server/room.js 5f731f954034e7a3ffaea1d52c8c2b07ddeeca8b19d4908731de8c5c112d350f
check package.json 60ab9e31fe41bf19729ea5814ccce8127d2f1f8b49d7d7845f3ae85dd4ffc042
check tests/v6-korea-library.test.js 30e508e6f0b9006bc0a05f88480cb24941b3828396e0312032bec9973558dcab
check tests/scene-v51.test.js e62cbbf95a328a4ef050637dc84f1350f7554eb352b30221931912959bee6d5b
check tests/scene-v55.test.js 86cb4dd3263bb0677794c4da30b64793661b24ecf72de8b33f1f16e2040732b2
BACKUP_ROOT="${STUDYROOM_SCENE_BACKUP_ROOT:-/home/codespace/.config/snu-studyroom}"
BACKUP="$BACKUP_ROOT/scene-pre-v61-$(date -u +%Y%m%dT%H%M%SZ)-$$"
mkdir -p "$BACKUP/server" "$BACKUP/tests"
chmod 700 "$BACKUP"
for file in "${SOURCE_FILES[@]}";do cp "$PROJECT/$file" "$BACKUP/$file";done
changed=false
rollback(){
 if [[ "$changed" == true ]];then
  for file in "${SOURCE_FILES[@]}";do cp "$BACKUP/$file" "$PROJECT/$file";done
  rm -f "$PROJECT/$NEW_FILE"
  echo 'ROLLBACK_OK: 변경 전 V6.0 소스가 복구되었습니다.' >&2
 fi
}
on_error(){ local code=$?; trap - ERR INT TERM;rollback;exit "$code"; }
trap on_error ERR INT TERM
changed=true
for file in "${SOURCE_FILES[@]}" "$NEW_FILE";do cp "$BASE/payload/$file" "$PROJECT/$file";done
if (cd "$PROJECT" && npm run check > "$BACKUP/check.log" 2>&1 && npm test > "$BACKUP/test.log" 2>&1);then
 changed=false;trap - ERR INT TERM
 echo 'V61_THREE_LIBRARIES_PATCH_OK: Seoul, Korea, Yonsei / 48 seats each / rotated separated supports.'
 echo "SOURCE_BACKUP: $BACKUP"
 tail -n 13 "$BACKUP/test.log"
 echo 'Railway 배포 전입니다. 실제 웹 화면은 배포 후 확인하세요.'
else
 echo 'V61_PATCH_FAILED: 검사 실패. 자동 복원합니다.' >&2
 tail -n 35 "$BACKUP/test.log" 2>/dev/null || tail -n 35 "$BACKUP/check.log" >&2 || true
 false
fi
