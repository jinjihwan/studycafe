# V6.1 — 연세대학교 도서관 / 고려대 표시명 / 서울대 90도 기둥 수정

## 변경 내용

- 방 3개: `?room=main` 서울대학교 중앙도서관, `?room=korea` 고려대학교 중앙도서관, `?room=yonsei` 연세대학교 연세·삼성학술정보관
- 서울대 8개 공동 책상 × 6석 = 48석 유지; 고려대 24개 양면 책상 × 2석 = 48석 유지
- 연세대: 실제 연세·삼성학술정보관 내부 자료를 참고해 제작한 밝은 블루 카펫, 유리 난간·복층 시각 요소, 개별 독서 부스(24개 × 2석 = 48석). 실제 사진·학교 로고는 코드에 포함하지 않았습니다.
- 고려대 **사용자에게 보이는 명칭**의 `(대학원)` 제거 → `고려대학교 중앙도서관`
- 서울대 기둥: ㅅ 지지대를 **Y축 기준 90도 회전한 효과**. 두 개의 대각선 부재는 동일 X 위치를 공유하고, 앞뒤 방향 Z로만 기울어집니다. 상단은 서로 닿지 않는 두 독립 접촉점(약 1.84 3D 단위 간격)으로 천장 보를 지지합니다. 클라이언트와 서버의 바닥 장애물 좌표를 함께 수정했습니다.
- 좌석 잠금, 채팅, 다른 사람 아바타는 방별로 분리하며 누적 공부 시간·친구·랭킹은 공통 유지. PostgreSQL 스키마나 Railway 환경변수 변경 없음.

## 적용: 항상 GitHub ZIP → Codespaces

`SNU_StudyRoom_V6_1_Three_Libraries_PATCH.zip`을 **GitHub 저장소 `jinjihwan/studycafe`의 루트**에 `Add file → Upload files`로 추가하고 Commit changes. 그다음 Codespaces:

```bash
cd /workspaces/studycafe
git pull --ff-only
mkdir -p /home/codespace/v61-three-libraries
unzip -o SNU_StudyRoom_V6_1_Three_Libraries_PATCH.zip -d /home/codespace/v61-three-libraries
bash /home/codespace/v61-three-libraries/apply_v61_three_libraries.sh
```

성공하면 `V61_THREE_LIBRARIES_PATCH_OK`를 확인합니다. 정확한 V6.0 파일 해시가 아니면 `SAFETY_STOP`으로 중단하며 임의 덮어쓰지 않습니다. 이전 소스는 `/home/codespace/.config/snu-studyroom/scene-pre-v61-*`에 자동 보관합니다. 테스트 실패하면 코드를 자동 복원합니다.

## GitHub 기록 및 배포

패치 성공 후 아래 명령을 실행하면 GitHub에 푸시합니다. **기존 Railway 설정에서 GitHub 자동 배포가 연결돼 있다면 `git push` 즉시 공개 사이트의 배포가 시작됩니다.** 사용자 접속이 적은 시간에 실행하세요.

```bash
cd /workspaces/studycafe

git add -- \
  SNU_3D_StudyRoom_v5_3_postgresql/index.html \
  SNU_3D_StudyRoom_v5_3_postgresql/server/room.js \
  SNU_3D_StudyRoom_v5_3_postgresql/package.json \
  SNU_3D_StudyRoom_v5_3_postgresql/tests/scene-v51.test.js \
  SNU_3D_StudyRoom_v5_3_postgresql/tests/scene-v55.test.js \
  SNU_3D_StudyRoom_v5_3_postgresql/tests/v6-korea-library.test.js \
  SNU_3D_StudyRoom_v5_3_postgresql/tests/v61-three-libraries.test.js

git commit -m "V6.1 add Yonsei library and rotate Seoul pillars"
git push origin main
```

배포 조회:

```bash
cd /workspaces/studycafe/SNU_StudyRoom_PG_Backup_Worker
railway deployment list --service focused-benevolence --environment production
```

최신 배포가 `SUCCESS`인지 확인. 기존 Railway PostgreSQL 및 Cloudflare R2 백업 전용 서비스는 변경하지 않습니다.

## 기능 확인 주소

- 서울대: https://focused-benevolence-production-db18.up.railway.app/?room=main
- 고려대: https://focused-benevolence-production-db18.up.railway.app/?room=korea
- 연세대: https://focused-benevolence-production-db18.up.railway.app/?room=yonsei

도서관 변경을 이용해 3개 방 이동을 확인하고, 착석 및 공부 기록을 새로고침 후에도 점검하세요. 특히 서울대 기둥은 정면/측면에서 각각 다른 모습으로 보이는지 3D 카메라 회전으로 확인하세요.

## 실제 연세대 참고 자료

- 연세대학교 공식 대학 건물 소개: https://yonsei.ac.kr/en_sc/1822/subview.do
- 연세대학교 제공 2016년 연세·삼성학술정보관 실내 사진: https://www.yonsei.ac.kr/_attach/editor_image/2016-07/uzwptrgmhruw.jpg
- 연세대 도서관 공식 시설 안내·VR 투어: https://gsis.yonsei.ac.kr/gosc/life/libraries01.do

실내 사진은 **참고만** 했으며 앱 내에 직접 포함하지 않았습니다. 재현은 실제 건물과 비슷한 시각적 요소를 가진 비공식 절차적 3D 모델로, 설계 도면이나 3D 스캔에 기초한 완전 복제는 아닙니다.
