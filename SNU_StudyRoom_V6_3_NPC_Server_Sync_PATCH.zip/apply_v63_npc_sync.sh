#!/usr/bin/env bash
# V6.3 NPC: authoritative choreography and reserved chairs, first room only.
# Strict V6.2 validation, source backup, automatic rollback after failing tests.
set -euo pipefail
PACKAGE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT="${STUDYROOM_PROJECT_DIR:-/workspaces/studycafe/SNU_3D_StudyRoom_v5_3_postgresql}"
MODIFIED=(index.html server/room.js server/account-api.js package.json)
NEW=(tests/v63-npc-consistency.test.js)
FILES=("${MODIFIED[@]}" "${NEW[@]}")
stop(){ echo "SAFETY_STOP: $1" >&2; exit 2; }
[[ -f "$PROJECT/index.html" && -f "$PROJECT/server/room.js" ]] || stop "프로젝트 폴더를 찾지 못했습니다: $PROJECT"
complete=true
for file in "${FILES[@]}";do
 [[ -f "$PROJECT/$file" ]] && cmp -s "$PROJECT/$file" "$PACKAGE/payload/$file" || { complete=false; break; }
done
if [[ "$complete" == true ]];then
 echo 'V63_ALREADY_APPLIED: NPC 동기화 패치가 이미 적용되어 있습니다.'
 exit 0
fi
for file in "${NEW[@]}";do [[ ! -e "$PROJECT/$file" ]] || stop "새 테스트 파일이 이미 존재합니다: $file";done
check_base(){
 local file="$1" expected="$2" received
 [[ -f "$PROJECT/$file" ]] || stop "원본 파일이 없습니다: $file"
 received="$(sha256sum "$PROJECT/$file" | cut -d' ' -f1)"
 [[ "$received" == "$expected" ]] || stop "V6.2 기준 코드와 다릅니다: $file (원본 보존)"
}
check_base index.html 301363963a04db9cb622df01e7620174f8e1925c56c5e95c152d2f11c3b6ec4d
check_base server/room.js 5b795a3b5d77f485d5d2014f1617ca85dd2e809a5084e5c5f6be8fecefc6ce6c
check_base server/account-api.js ae2ad3a9c27f5c79031c0844871c39ea2abf62f14c7c4e8b8de5a69e48936879
check_base package.json 59f525d4b5a5e0007098ea0c62cd4fdc579f0ecd002c329b83046ffe6c0cc830

BACKUP_ROOT="${STUDYROOM_SCENE_BACKUP_ROOT:-/home/codespace/.config/snu-studyroom}"
BACKUP="$BACKUP_ROOT/npc-pre-v63-$(date -u +%Y%m%dT%H%M%SZ)-$$"
mkdir -p "$BACKUP/server" "$BACKUP/tests"
chmod 700 "$BACKUP"
for file in "${MODIFIED[@]}";do cp "$PROJECT/$file" "$BACKUP/$file";done
changed=false
rollback(){
 if [[ "$changed" == true ]];then
   for file in "${MODIFIED[@]}";do cp "$BACKUP/$file" "$PROJECT/$file";done
   for file in "${NEW[@]}";do rm -f "$PROJECT/$file";done
   echo 'ROLLBACK_OK: 검사 실패로 기존 V6.2 코드가 복원됐습니다.' >&2
 fi
}
on_error(){ local status=$?;trap - ERR INT TERM;rollback;exit "$status"; }
trap on_error ERR INT TERM
changed=true
for file in "${FILES[@]}";do
  mkdir -p "$(dirname "$PROJECT/$file")"
  cp "$PACKAGE/payload/$file" "$PROJECT/$file"
done
if (cd "$PROJECT" && npm run check > "$BACKUP/check.log" 2>&1 && npm test > "$BACKUP/test.log" 2>&1);then
 changed=false;trap - ERR INT TERM
 echo 'V63_NPC_SYNC_PATCH_OK: 첫 방 NPC 8명 + 추가 방 0명 + 서버 동기화 좌석 점유'
 echo "SOURCE_BACKUP: $BACKUP"
 tail -n 14 "$BACKUP/test.log"
 echo '현재 로컬 코드에만 적용됐습니다. GitHub 푸시 전입니다.'
else
 echo 'V63_PATCH_TEST_FAILED: 자동 복구를 시작합니다.' >&2
 tail -n 45 "$BACKUP/test.log" 2>/dev/null || tail -n 45 "$BACKUP/check.log" >&2 || true
 false
fi
