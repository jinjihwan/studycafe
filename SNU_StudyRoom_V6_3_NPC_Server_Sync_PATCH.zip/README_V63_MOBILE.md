# V6.3 NPC 동기화 및 NPC 없는 추가 방 패치

## 수정 내용

- 원인: V6.2 브라우저의 `updateNpcBehaviors`가 각 클라이언트에서 `Math.random()`을 사용해 서로 다른 NPC 동선을 만들었습니다. 한편 서버는 NPC 전용 8개 좌석을 계속 차단했습니다.
- 해결: NPC의 걷기/쉬기/앉기/스트레칭 상태는 `server/room.js`가 계산하고 `welcome`, `clock`, `snapshot`으로 모든 방문자에게 전송합니다.
- NPC 8명은 **각 대학의 첫 번째 방** `main`, `korea`, `yonsei`에만 존재합니다. NPC의 지정 좌석은 외출 중에도 서버가 예약합니다.
- `main-2`, `korea-2`, `yonsei-2` 같은 추가 방은 같은 대학의 3D 공간을 사용하면서 NPC가 0명이고, 48석 모두 실제 이용자가 사용할 수 있습니다.
- 서버 좌석 판정, 클라이언트 표시, 친구 근처 자리 추천이 동일한 방 ID 기준을 사용합니다.
- 로그인·PostgreSQL·공부시간·랭킹·친구 관계·R2 백업 설정은 변경하지 않습니다.

**중요:** 이 패치는 자동으로 방을 생성하거나 2,000명 규모의 서버 분산을 구현하지 않습니다. 방 자동 배정, 다중 서버, Redis, 부하 테스트는 별도 작업입니다. 실제 브라우저 동기화도 배포 후 여러 기기로 확인해야 합니다.

## GitHub → Codespaces 설치

1. `SNU_StudyRoom_V6_3_NPC_Server_Sync_PATCH.zip` 파일을 GitHub `jinjihwan/studycafe` 루트에 업로드하고 `Commit changes`를 누릅니다.
2. Codespaces에서 아래 실행합니다.

```bash
cd /workspaces/studycafe
git pull --ff-only
mkdir -p /home/codespace/v63-npc-sync
unzip -o SNU_StudyRoom_V6_3_NPC_Server_Sync_PATCH.zip -d /home/codespace/v63-npc-sync
bash /home/codespace/v63-npc-sync/apply_v63_npc_sync.sh
```

성공 기준은 `V63_NPC_SYNC_PATCH_OK`입니다. `SAFETY_STOP`이나 테스트 오류가 있으면 이후 명령을 실행하지 마세요. 패치는 원본 SHA-256을 확인하고, 별도 백업을 만든 뒤 검사 실패 시 롤백합니다.

3. 정상 적용 후에만 변경 코드 푸시:

```bash
cd /workspaces/studycafe
git add -- \
 SNU_3D_StudyRoom_v5_3_postgresql/index.html \
 SNU_3D_StudyRoom_v5_3_postgresql/server/room.js \
 SNU_3D_StudyRoom_v5_3_postgresql/server/account-api.js \
 SNU_3D_StudyRoom_v5_3_postgresql/package.json \
 SNU_3D_StudyRoom_v5_3_postgresql/tests/v63-npc-consistency.test.js
git commit -m "V6.3 server-authoritative NPCs and NPC-free overflow rooms"
git push origin main
```

4. Railway에서 실제 운영 서버 `focused-benevolence`의 최신 배포가 SUCCESS인지 확인합니다.

```bash
cd /workspaces/studycafe/SNU_StudyRoom_PG_Backup_Worker
railway deployment list --service focused-benevolence --environment production
```

## 수동 검증 (서로 다른 기기 두 대)

- `?room=main`으로 동시에 접속하여 NPC의 착석/휴식/보행 동작과 잠긴 좌석 번호가 두 화면에서 일치하는지 비교합니다.
- `?room=yonsei-2`에 접속하여 NPC가 표시되지 않고 48석 전부 착석 가능한지 확인합니다. 이는 수동 인스턴스 진입 테스트이며 자동 방 생성 기능이 있다는 뜻이 아닙니다.
- 두 기기에서 동시에 같은 일반 좌석을 요청했을 때 한 사람만 착석하고 다른 사람은 거절되는지 확인합니다.
- 서울대·고려대·연세대 방 이동 후 공부 시간이 계속 기록되는지 확인합니다.

## 수정 파일

- `index.html` — 서버 NPC 포즈 수신, 첫 방만 NPC 출력, 추가방의 대학별 3D 지오메트리 식별
- `server/room.js` — 서버 권위 NPC 상태, NPC 지정 좌석 예약, 추가방 NPC 해제
- `server/account-api.js` — 친구 근처 추천에서 추가방 NPC 예약 해제 반영
- `package.json` — 버전 표시
- `tests/v63-npc-consistency.test.js` — 서버 동기화, 클론방 NPC 없음, 좌석 권위 테스트
