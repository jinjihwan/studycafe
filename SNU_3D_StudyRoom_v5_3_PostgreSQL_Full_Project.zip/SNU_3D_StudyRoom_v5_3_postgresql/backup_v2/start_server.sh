#!/bin/sh
cd "$(dirname "$0")"
exec node server/index.js
