# V6 고려대학교 중앙도서관(대학원) 대열람실 — 모바일 패치

## 변경된 기능

- 서울대 기존 공간(`?room=main`)을 유지하면서, 고려대 중앙도서관(대학원) 대열람실(`?room=korea`)을 별도 실시간 3D 방으로 추가
- 실제 2021년 재개관한 대열람실의 고딕식 높은 아치 창, 진홍색 커튼, 나무 마루, 짙은 목재 열람 책상과 고전적인 독서등, 높이 매달린 27개의 펜던트 조명을 참고한 **자체 Three.js 3D 메쉬**. 실제 사진이나 대학 로고 파일을 앱에 복제하지 않았습니다.
- 서울대: 8개 공동 책상 × 6석 = 48석; 고려대: 24개 양면 목재 열람 책상 × 2석 = 48석. 각 방마다 NPC 8명, 실제 이용자용 좌석 40석.
- 상단 **도서관 변경** 메뉴로 두 방 이동. 접속·좌석·채팅은 방별로 분리, 공부 기록과 랭킹·친구는 계정 기준 공통.
- 서버가 공부 시간 저장에 성공한 뒤 이동을 승인합니다. 실패하면 브라우저에 오류를 표시하고 안전하게 재연결할 수 있습니다.
- 친구 따라가기는 목적지 도서관의 빈 좌석 지도를 사용하도록 서버를 수정.
- 첫 방문자 캐릭터 설정 후 도서관 선택 화면 제공. 기존 구글/게스트 인증은 유지.
- DB 스키마 수정 없음. PostgreSQL 환경변수, Firebase 비밀키, Cloudflare R2 백업 설정 변경 없음.

## 코드 패치 적용 순서 (GitHub → Codespaces)

**주의: 바로 전 V5.5 커밋의 `git push origin main`이 GitHub 500 오류로 실패한 이력이 있습니다. 먼저 Codespaces에서 기존 커밋을 GitHub에 푸시해 두세요. 그렇지 않으면 GitHub 웹에서 새 ZIP을 업로드한 후 로컬 브랜치와 원격 브랜치가 갈라져 `git pull --ff-only`가 실패할 수 있습니다.**

```bash
cd /workspaces/studycafe
git push origin main
```

위 명령이 성공한 것을 확인한 **다음에** GitHub `jinjihwan/studycafe` 저장소의 **Add file → Upload files**에서 `SNU_StudyRoom_V6_0_Korea_Library_PATCH.zip`을 업로드하고 커밋합니다. Codespaces에서는:

```bash
cd /workspaces/studycafe
git pull --ff-only
mkdir -p /home/codespace/v6-korea-patch
unzip -o SNU_StudyRoom_V6_0_Korea_Library_PATCH.zip -d /home/codespace/v6-korea-patch
bash /home/codespace/v6-korea-patch/apply_v6_korea_patch.sh
```

정상 결과: `V6_KOREA_PATCH_OK`, 59개 테스트 중 58개 통과, 1개 건너뜀(실제 PostgreSQL 필요), 실패 0. 버전 해시가 다르면 기존 파일을 덮어쓰지 않고 **SAFETY_STOP**합니다. 패치 이전 소스는 `/home/codespace/.config/snu-studyroom/scene-pre-v6-korea-*`에 복사됩니다.

## 적용 후 코드 저장

운영 서버는 아직 배포하지 않습니다. 테스트 결과를 확인하고 다음 단계를 진행하세요.

```bash
cd /workspaces/studycafe
git add -- SNU_3D_StudyRoom_v5_3_postgresql/index.html SNU_3D_StudyRoom_v5_3_postgresql/server/room.js SNU_3D_StudyRoom_v5_3_postgresql/server/account-api.js SNU_3D_StudyRoom_v5_3_postgresql/package.json SNU_3D_StudyRoom_v5_3_postgresql/tests/v6-korea-library.test.js
git commit -m 'V6 add Korea University library room'
```

`git push origin main`은 Railway가 GitHub 자동 배포 중이라면 **바로 공개 서비스에 적용될 수 있습니다.** 사용자가 접속하지 않는 시점에 확인 후 진행하는 것이 안전합니다. 좌석 배치가 달라지므로 기존 접속자는 페이지를 다시 열어야 합니다.

## 확인 사항

1. 서울대 `?room=main` 화면은 기존 삼각 지지대와 8개 책상이 유지되는지
2. 고려대 `?room=korea` 화면에 붉은 커튼, 아치형 창, 27개 펜던트, 목재 책상 24개가 나타나는지
3. 두 기기로 서로 다른 도서관 접속 시 아바타와 채팅이 섞이지 않는지
4. 고려대에서 앉고, 도서관을 바꾼 뒤 기존 자리가 자동으로 비워지는지
5. 공부 기록(통합 합산), Google 로그인, 친구 동행, R2 백업 유지 확인

### 사진·공식 참고

- 고려대학교 도서관 보도자료, 2021-08-27: https://library.korea.ac.kr/about/press-release/?lang=en&mod=document&uid=16316
- 공식 고려대학교 도서관 시설 안내: https://www.korea.ac.kr/en/1098/subview.do

실내 건축자료는 참고용이며 실제 치수와 일부 배치는 사진에 보이지 않아 추정 모델링된 비공식 학습 공간입니다. 이 버전에서는 **연세대 공간은 아직 추가하지 않았습니다.**
