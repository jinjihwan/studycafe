# V6 고려대학교 도서관 통합 테스트 보고서

- 기준 소스: V5.5 Triangle/Guest/Ripples 패치 적용본
- 추가 공간: 고려대 중앙도서관(대학원) 대열람실 (`?room=korea`)
- SNU 원본 유지: 좌석 48개 / NPC 8개, 삼각 지지대
- Korea: 별도 24개 책상 × 2석 = 48석 / NPC 8개, 별도 장애물·좌석 권한
- 서버는 `layoutForRoom(room.id)`를 사용해 방별 좌석 예약/이동/친구 동행 빈자리 검증
- 명시적 도서관 변경(`room_exit`)은 저장 완료 후 승인하고 기존 좌석을 해제
- 사진/로고 파일은 배포하지 않으며 기존 Firebase·PostgreSQL·R2 자격 증명은 패치에 포함하지 않음

검증 명령:

```bash
npm run check
npm test
```

검증 결과(현재 세션):

```text
index.html module syntax: OK
Project assets: OK (43 required files); imported local modules present
# tests 59
# pass 58
# fail 0
# skipped 1
```

추가 4개 테스트:

- Korea 대열람실 특성, 27 펜던트·방 선택 UI
- SNU 48석 유지 및 KU 24×2 좌석/서버 장애물 검증
- 친구 합류 좌석 추천이 목적지 방 레이아웃을 사용
- 가상 클라이언트 2개의 실시간 방 격리와 도서관 이동 시 공부 기록 저장·좌석 해제

**실제 모바일/데스크톱 GPU 렌더링, Railway 운영 PostgreSQL 접속, Google 로그인 팝업, 정식 배포는 이번 로컬 검증에 포함되지 않았습니다.** 자동 테스트는 실제 사용자 시나리오 검증을 대체하지 않습니다.
