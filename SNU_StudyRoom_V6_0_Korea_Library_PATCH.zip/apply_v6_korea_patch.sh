#!/usr/bin/env bash
set -euo pipefail
BASE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT="${STUDYROOM_PROJECT_DIR:-/workspaces/studycafe/SNU_3D_StudyRoom_v5_3_postgresql}"
if [[ ! -f "$PROJECT/index.html" || ! -f "$PROJECT/server/room.js" || ! -f "$PROJECT/server/account-api.js" ]]; then
 echo "SAFETY_STOP: 스터디카페 프로젝트 경로가 올바르지 않습니다: $PROJECT" >&2;exit 1
fi
hash(){ sha256sum "$PROJECT/$1" | cut -d' ' -f1; }
check(){
 local got;got="$(hash "$1")"
 if [[ "$got" != "$2" ]];then
  echo "SAFETY_STOP: 기존 V5.5 파일 버전이 다릅니다: $1" >&2
  echo "현재 파일을 덮어쓰지 않았습니다. 변경된 파일이 있다면 임의 삭제하지 마세요." >&2
  exit 2
 fi
}
# Previous complete application (idempotent).
if [[ "$(hash index.html)" == '5db5e52a09385aeecdfbdfec5a840101ed635d5044d5e34dac0432af77349ee7' && \
      "$(hash server/room.js)" == '5f731f954034e7a3ffaea1d52c8c2b07ddeeca8b19d4908731de8c5c112d350f' && \
      -f "$PROJECT/tests/v6-korea-library.test.js" ]]; then
 echo 'V6_KOREA_ALREADY_APPLIED: 고려대학교 방이 이미 적용되어 있습니다.';exit 0
fi
check index.html e34dcdcc6e1066ec9f8672119da88b415edd4c10a111e4c0ace845bead656fbf
check server/room.js 7ce5ca4e750ffb0f236d0d12973172c0e1df5c74c3c649062e7c77145cd76560
check server/account-api.js 4354e68eaaf838be2191e66323ab0c2ee7c7e48d7c868bac6fcc7b7933786910
check package.json add8f3721f97755657ca28c069b6ecfd097560f7c7248823a97391f42a549dc0
if [[ -e "$PROJECT/tests/v6-korea-library.test.js" ]]; then
 echo 'SAFETY_STOP: V6 테스트 파일이 이미 존재해 덮어쓰기 위험이 있습니다.' >&2;exit 2
fi
BACKUP_ROOT="${STUDYROOM_SCENE_BACKUP_ROOT:-/home/codespace/.config/snu-studyroom}"
BACKUP="$BACKUP_ROOT/scene-pre-v6-korea-$(date -u +%Y%m%dT%H%M%SZ)"
mkdir -p "$BACKUP" "$BACKUP/server"
for file in index.html server/room.js server/account-api.js package.json;do
 cp "$PROJECT/$file" "$BACKUP/$file"
done
rollback(){
 for file in index.html server/room.js server/account-api.js package.json;do cp "$BACKUP/$file" "$PROJECT/$file";done
 rm -f "$PROJECT/tests/v6-korea-library.test.js"
}
for file in index.html server/room.js server/account-api.js package.json tests/v6-korea-library.test.js;do
 cp "$BASE/payload/$file" "$PROJECT/$file"
done
if (cd "$PROJECT" && npm run check >"$BACKUP/check.log" 2>&1 && npm test >"$BACKUP/test.log" 2>&1);then
 echo 'V6_KOREA_PATCH_OK: Seoul and Korea library rooms, 48 seats each, isolated multiplayer, persistent study on switch.'
 echo "SOURCE_BACKUP: $BACKUP"
 tail -n 12 "$BACKUP/test.log"
 echo 'Railway 운영 서버에는 아직 배포되지 않았습니다.'
else
 echo 'V6_KOREA_PATCH_FAILED: 테스트 실패. V5.5 파일로 되돌립니다.' >&2
 rollback
 tail -n 40 "$BACKUP/test.log" 2>/dev/null || tail -n 40 "$BACKUP/check.log" >&2 || true
 exit 3
fi
