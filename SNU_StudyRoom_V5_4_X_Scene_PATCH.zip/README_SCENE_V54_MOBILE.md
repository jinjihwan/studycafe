# 스터디카페 V5.4 공간 구조 변경 패치 (V5.3 PostgreSQL 기반)

## 실제 적용 내용
- 제공한 원본 사진을 참고하여 좌·우 대각으로 교차하는 거대한 철골 X 보강재를 바닥에서 천장까지 기울어지게 배치했습니다. 수직 기둥 표면에 X를 그린 형태가 아니라 기울어진 실제 3D 구조물입니다.
- 책상 8개(왼쪽 4개, 오른쪽 4개), 각 책상 양쪽에 3개씩 의자 6개 = 총 48석.
- NPC 8명은 서로 다른 지정 좌석에 유지. 실제 이용자는 한 방에서 최대 40석 착석할 수 있습니다. 실제 웹소켓 최대 인원 제한(64)은 별도입니다.
- 서버의 좌석 좌표·충돌 좌표를 클라이언트와 동일하게 변경했으므로 착석 및 길찾기가 동작하도록 구성했습니다.
- Google 로그인, 친구, 랭킹, 공부 기록, PostgreSQL, Railway의 백업 설정은 변경하지 않습니다.

## 스마트폰 Codespaces 적용
1. GitHub Codespaces에서 /workspaces/studycafe 폴더에 `SNU_StudyRoom_V5_4_X_Scene_PATCH.zip`을 업로드합니다.
2. 터미널에 다음 명령을 입력합니다.

```sh
mkdir -p /home/codespace/scene-v54-patch && unzip -o /workspaces/studycafe/SNU_StudyRoom_V5_4_X_Scene_PATCH.zip -d /home/codespace/scene-v54-patch && bash /home/codespace/scene-v54-patch/apply_scene_patch.sh
```

3. `SCENE_PATCH_OK` 출력 확인. 구버전은 홈의 `~/.config/snu-studyroom/scene-pre-v54-...`에 별도로 백업됩니다.
4. **실제 서비스에는 아직 배포되지 않습니다.** 코드 및 테스트가 통과한 뒤 운영 앱 `focused-benevolence`에만 배포하세요(백업 전용 서비스 `studyroom-pg-backup`에는 절대 배포하지 마세요).
5. 운영 중인 이용자가 없는 시간에 기존 앱만 배포하세요. 배포되면 현재 WebSocket 연결이 잠시 끊길 수 있습니다.

## 배포 전후 확인
- `cd /workspaces/studycafe/SNU_3D_StudyRoom_v5_3_postgresql && npm run check && npm test`
- 좌석 총 48개, 테이블 8개, NPC 8개, 두 기기 동시 착석, 재접속 후 공부 기록과 랭킹 정상.
- 기존 계정과 DB는 삭제하거나 마이그레이션할 필요가 없습니다.

## 안전장치
- 패치는 원본 V5.3 파일 해시와 정확히 일치할 때만 적용합니다. 다른 수정이 들어갔다면 `SAFETY_STOP`으로 중단하며 파일을 덮어쓰지 않습니다.
- 패치 적용 실패 시 소스 파일을 원상복구합니다. 운영 DB와 R2에는 접근하지 않습니다.
- 코드 검사 완료: `npm run check` 통과, `npm test`: 49 통과, 1개 PostgreSQL 실연결 테스트는 환경 부재로 건너뜀(2026-11-04 테스트 환경).
