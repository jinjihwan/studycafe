#!/usr/bin/env bash
set -euo pipefail
BASE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT="${STUDYROOM_PROJECT_DIR:-/workspaces/studycafe/SNU_3D_StudyRoom_v5_3_postgresql}"
if [[ ! -f "$PROJECT/index.html" || ! -f "$PROJECT/server/room.js" ]]; then
 echo "ERROR: 프로젝트 폴더를 찾을 수 없습니다: $PROJECT" >&2
 exit 1
fi
IDX="$(sha256sum "$PROJECT/index.html" | cut -d' ' -f1)"
ROOM="$(sha256sum "$PROJECT/server/room.js" | cut -d' ' -f1)"
if [[ "$IDX" == "6fa11781bf6f449a12e7518d517652cbd2fbd7e4654d60883b391964a212c97b" && "$ROOM" == "d8865533ed3cb3239b34f848d4dd1b869d17d5eb96580cd615051b381e3fd67d" ]]; then
 echo "SCENE_PATCH_ALREADY_APPLIED: 이 버전이 이미 설치되어 있습니다."
 exit 0
fi
if [[ "$IDX" != "d6c806830fb2bc8097fa245c92c3e1fe24608ceee6fde63b50bfbe70e76df435" || "$ROOM" != "047747e2e11cfa73d6c40140ddf1efd5f553ade64b804af1319dd4e381fb1923" ]]; then
 echo "SAFETY_STOP: 현 프로젝트 파일이 제공된 V5.3 원본과 다릅니다." >&2
 echo "다른 변경사항이 지워지는 것을 막기 위해 덮어쓰지 않았습니다." >&2
 echo "프로젝트의 index.html과 server/room.js를 직접 첨부해 주시면 그 버전에 맞춰 다시 수정할 수 있습니다." >&2
 exit 2
fi
BACKUP="${STUDYROOM_SCENE_BACKUP_ROOT:-/home/codespace/.config/snu-studyroom}/scene-pre-v54-$(date -u +%Y%m%dT%H%M%SZ)"
mkdir -p "$BACKUP"
cp "$PROJECT/index.html" "$BACKUP/index.html"
cp "$PROJECT/server/room.js" "$BACKUP/room.js"
cp "$PROJECT/tests/scene-v51.test.js" "$BACKUP/scene-v51.test.js"
cp "$PROJECT/package.json" "$BACKUP/package.json"
cp "$BASE/payload/index.html" "$PROJECT/index.html"
cp "$BASE/payload/room.js" "$PROJECT/server/room.js"
cp "$BASE/payload/scene-v51.test.js" "$PROJECT/tests/scene-v51.test.js"
node -e 'const fs=require("fs"); const p=process.argv[1]; const j=JSON.parse(fs.readFileSync(p,"utf8")); if(j.version==="5.3.0"){j.version="5.4.0";fs.writeFileSync(p,JSON.stringify(j,null,2)+"\n")}' "$PROJECT/package.json"
if (cd "$PROJECT" && npm run check > "$BACKUP/check.log" 2>&1 && npm test > "$BACKUP/test.log" 2>&1); then
 echo "SCENE_PATCH_OK: 8 tables, 6 chairs each, diagonal X support (48 seats, 8 NPC)."
 echo "BACKUP_SAVED: $BACKUP"
 echo "TEST SUMMARY:"
 tail -n 10 "$BACKUP/test.log"
 echo "프로덕션 배포는 아직 진행하지 않았습니다."
else
 cp "$BACKUP/index.html" "$PROJECT/index.html"
 cp "$BACKUP/room.js" "$PROJECT/server/room.js"
 cp "$BACKUP/scene-v51.test.js" "$PROJECT/tests/scene-v51.test.js"
 cp "$BACKUP/package.json" "$PROJECT/package.json"
 echo "SCENE_PATCH_FAILED: 검사에 실패해 기존 코드를 복원했습니다." >&2
 tail -n 30 "$BACKUP/test.log" 2>/dev/null || tail -n 30 "$BACKUP/check.log" >&2 || true
 exit 3
fi
