import { createCipheriv, createDecipheriv, randomBytes } from 'node:crypto';
import { createReadStream, createWriteStream } from 'node:fs';
import { appendFile, open, stat, unlink } from 'node:fs/promises';
import { pipeline } from 'node:stream/promises';

// Format: 8-byte magic + 12-byte nonce + AES-256-GCM ciphertext + 16-byte tag.
// This is intentionally versioned. Do not change it without migration support.
export const MAGIC = Buffer.from('SNUDB01\0');
export const NONCE_BYTES = 12;
export const TAG_BYTES = 16;
export const HEADER_BYTES = MAGIC.length + NONCE_BYTES;

export function readKey(base64) {
  if (typeof base64 !== 'string' || !/^[A-Za-z0-9+/]{43}=$/.test(base64.trim())) {
    throw new Error('BACKUP_ENCRYPTION_KEY_B64 must be a base64-encoded 32-byte key');
  }
  const key = Buffer.from(base64.trim(), 'base64');
  if (key.length !== 32 || key.toString('base64') !== base64.trim()) {
    throw new Error('Invalid encryption key');
  }
  return key;
}

export async function encryptFile(input, output, key) {
  if (!Buffer.isBuffer(key) || key.length !== 32) throw new Error('Invalid encryption key');
  const nonce = randomBytes(NONCE_BYTES);
  const cipher = createCipheriv('aes-256-gcm', key, nonce);
  const out = createWriteStream(output, { flags: 'wx', mode: 0o600 });
  try {
    out.write(MAGIC);
    out.write(nonce);
    await pipeline(createReadStream(input), cipher, out);
    await appendFile(output, cipher.getAuthTag());
    return (await stat(output)).size;
  } catch (e) {
    await unlink(output).catch(() => {});
    throw e;
  }
}

export async function decryptFile(input, output, key) {
  if (!Buffer.isBuffer(key) || key.length !== 32) throw new Error('Invalid encryption key');
  const f = await open(input, 'r');
  let size, header, tag;
  try {
    size = (await f.stat()).size;
    if (size <= HEADER_BYTES + TAG_BYTES) throw new Error('Encrypted backup too short');
    header = Buffer.alloc(HEADER_BYTES);
    tag = Buffer.alloc(TAG_BYTES);
    if ((await f.read(header, 0, HEADER_BYTES, 0)).bytesRead !== HEADER_BYTES) throw new Error('Invalid header');
    if (!header.subarray(0, MAGIC.length).equals(MAGIC)) throw new Error('Unsupported backup format');
    if ((await f.read(tag, 0, TAG_BYTES, size - TAG_BYTES)).bytesRead !== TAG_BYTES) throw new Error('Invalid tag');
  } finally {
    await f.close();
  }
  const decipher = createDecipheriv('aes-256-gcm', key, header.subarray(MAGIC.length));
  decipher.setAuthTag(tag);
  try {
    await pipeline(
      createReadStream(input, { start: HEADER_BYTES, end: size - TAG_BYTES - 1 }),
      decipher,
      createWriteStream(output, { flags: 'wx', mode: 0o600 }),
    );
  } catch {
    await unlink(output).catch(() => {});
    throw new Error('Decryption/authentication failed (wrong key or damaged backup)');
  }
}
