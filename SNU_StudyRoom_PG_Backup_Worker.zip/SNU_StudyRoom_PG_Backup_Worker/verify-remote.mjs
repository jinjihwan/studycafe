import { getR2Config, makeClient, listRecent } from './r2.mjs';
const cfg = getR2Config();
const client = makeClient(cfg);
try {
  const items = (await listRecent(client, cfg.bucket)).sort((a,b) => new Date(b.lastModified) - new Date(a.lastModified));
  if (!items.length) throw new Error('No backup objects found');
  for (const { key, bytes, lastModified } of items.slice(0, 5)) {
    console.log(`${lastModified?.toISOString()} ${bytes} ${key}`);
  }
  console.log('[verify] Cloudflare R2 backup objects found. Actual restore still requires a separate drill.');
} catch (e) { console.error('[verify] FAILED', e.message); process.exitCode = 1; }
finally { client.destroy(); }
