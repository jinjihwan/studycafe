import { spawn } from 'node:child_process';
import { mkdtemp, rm, stat } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { encryptFile, readKey } from './crypto.mjs';
import { getR2Config, makeClient, uploadAndVerify } from './r2.mjs';
import { buildObjectKey } from './backup-key.mjs';

function command(bin, args, env = process.env) {
  return new Promise((resolve, reject) => {
    const child = spawn(bin, args, { stdio: ['ignore', 'ignore', 'pipe'], env });
    let stderr = '';
    child.stderr.setEncoding('utf8');
    child.stderr.on('data', s => { stderr = (stderr + s).slice(-4096); });
    child.on('error', () => reject(new Error(`${bin} failed to start`)));
    child.on('close', code => code === 0 ? resolve() : reject(new Error(`${bin} returned exit code ${code}; check DB connectivity and credentials`)));
  });
}

async function main() {
  const env = process.env;
  if (!env.DATABASE_URL) throw new Error('Missing DATABASE_URL');
  const cfg = getR2Config(env);
  const key = readKey(env.BACKUP_ENCRYPTION_KEY_B64);
  const tmp = await mkdtemp(join(tmpdir(), 'snu-pg-backup-'));
  const dump = join(tmp, 'studyroom.dump');
  const encrypted = join(tmp, 'studyroom.dump.enc');
  const client = makeClient(cfg);
  const objectKey = buildObjectKey();
  try {
    console.log(`[backup] Started ${new Date().toISOString()}`);
    // pg_dump uses a consistent snapshot without stopping the live application.
    // The URL stays in the child process; it is never logged or committed.
    await command('pg_dump', ['--format=custom', '--compress=6', '--no-owner', '--no-acl', '--file', dump, '--dbname', env.DATABASE_URL],
      { ...env, PGCONNECT_TIMEOUT: '15' });
    if ((await stat(dump)).size < 32) throw new Error('pg_dump produced an invalid/empty archive');
    await command('pg_restore', ['--list', dump]);
    await encryptFile(dump, encrypted, key);
    const bytes = await uploadAndVerify(client, cfg.bucket, objectKey, encrypted);
    console.log(`[backup] SUCCESS uploaded and HEAD-verified object=${objectKey}, encrypted_bytes=${bytes}`);
  } finally {
    client.destroy();
    await rm(tmp, { recursive: true, force: true });
  }
}

main().catch(e => {
  // Avoid dumping secrets, raw remote error messages or the database URL to logs.
  console.error(`[backup] FAILED category=${e?.name || 'Error'}; details=${String(e?.message || 'unknown').replace(/postgres(?:ql)?:\/\/\S+/gi, '[REDACTED]').slice(0, 240)}`);
  process.exitCode = 1;
});
