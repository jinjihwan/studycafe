# 백업 워커 코드 테스트 보고서

- 실행 가능 환경: Node.js 22 이상
- `node --test tests/*.test.mjs` 통과: 4/4
- 검증 내용: AES-256-GCM 암·복호화, 위변조 및 잘못된 키 차단, base64 32바이트 키 검증, UTC 백업 파일 경로 생성.
- 미검증: 실제 Railway Cron 실행, 실제 Railway PostgreSQL `pg_dump`, Cloudflare R2 업로드/HEAD 검증, Docker 이미지 빌드, 운영 데이터베이스 복원. 외부 서비스 자격 증명 없이 검증할 수 없습니다.
- 백업이 실제로 작동한다고 주장하려면 첫 실행에서 `SUCCESS` 로그 및 R2 객체 확인과 별도 테스트 DB 복원이 필요합니다.
