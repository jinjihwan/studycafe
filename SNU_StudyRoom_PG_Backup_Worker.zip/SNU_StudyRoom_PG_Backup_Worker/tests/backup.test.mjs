import test from 'node:test';
import assert from 'node:assert/strict';
import { randomBytes } from 'node:crypto';
import { mkdtemp, writeFile, readFile, rm, stat } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { MAGIC, encryptFile, decryptFile, readKey } from '../crypto.mjs';
import { buildObjectKey } from '../backup-key.mjs';

test('AES256-GCM encryption/decryption roundtrip does not store plaintext', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'snu-encrypt-test-'));
  try {
    const original = join(dir, 'in'); const encrypted = join(dir, 'out.enc'); const restored = join(dir, 'restored');
    const payload = randomBytes(4096); const key = randomBytes(32);
    await writeFile(original, payload);
    await encryptFile(original, encrypted, key);
    const ciphertext = await readFile(encrypted);
    assert(ciphertext.subarray(0, MAGIC.length).equals(MAGIC));
    assert.equal(ciphertext.includes(payload.subarray(0, 128)), false);
    await decryptFile(encrypted, restored, key);
    assert((await readFile(restored)).equals(payload));
    assert((await stat(encrypted)).size > 4096);
  } finally { await rm(dir, {recursive:true,force:true}); }
});

test('tamper and wrong key fail without leaving plaintext output', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'snu-auth-test-'));
  try {
    const a=join(dir,'a'), b=join(dir,'b'), c=join(dir,'c');
    await writeFile(a,randomBytes(128));
    const key=randomBytes(32); await encryptFile(a,b,key);
    await assert.rejects(() => decryptFile(b,c,randomBytes(32)), /Decryption\/authentication failed/);
    await assert.rejects(() => stat(c), /ENOENT/);
    const bad=await readFile(b); bad[30] ^= 0xff;
    await writeFile(b,bad);
    await assert.rejects(() => decryptFile(b,c,key), /Decryption\/authentication failed/);
    await assert.rejects(() => stat(c), /ENOENT/);
  } finally { await rm(dir, {recursive:true,force:true}); }
});

test('keys require 32 bytes of strict base64', () => {
  const key=randomBytes(32); assert(readKey(key.toString('base64')).equals(key));
  assert.throws(() => readKey('short'));
});

test('S3 key is date-partitioned and excludes secrets', () => {
  assert.equal(buildObjectKey(new Date('2026-11-04T19:00:00Z')),
    'studyroom-backups/v1/2026/11/studyroom-2026-11-04T19-00-00-000Z.dump.enc');
});
