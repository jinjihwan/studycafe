// Pure function exported separately to allow testing without S3 network access.
export function buildObjectKey(now = new Date()) {
  const stamp = now.toISOString().replace(/[:.]/g, '-');
  const yyyy = stamp.slice(0, 4), mm = stamp.slice(5, 7);
  return `studyroom-backups/v1/${yyyy}/${mm}/studyroom-${stamp}.dump.enc`;
}
