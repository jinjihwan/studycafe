import { decryptFile, readKey } from './crypto.mjs';
const [, , input, output] = process.argv;
if (!input || !output) {
  console.error('Usage: BACKUP_ENCRYPTION_KEY_B64=... node decrypt.mjs input.dump.enc output.dump');
  process.exit(2);
}
try {
  const key = readKey(process.env.BACKUP_ENCRYPTION_KEY_B64);
  await decryptFile(input, output, key);
  console.log(`Decrypted to ${output}; check with pg_restore --list then restore to a separate TEST database.`);
} catch (e) { console.error('Decrypt failed:', e.message); process.exitCode = 1; }
