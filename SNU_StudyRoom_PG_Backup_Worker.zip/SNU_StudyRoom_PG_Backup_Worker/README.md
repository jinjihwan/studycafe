# 스터디룸 PostgreSQL 외부 자동 백업 · 스마트폰 안내

이 패키지는 **현재 v5.3 3D 서버를 수정하지 않고**, 같은 Railway 프로젝트에 별도 `studyroom-pg-backup` 예약 작업을 만드는 용도입니다.

구조: Railway Postgres(비공개 내부 연결) → Railway Cron(매일 19:00 UTC = 한국시간 다음 날 04:00) → pg_dump custom archive → AES-256-GCM 암호화 → 비공개 Cloudflare R2 버킷.

## 진행 전 확인
- 현재 Railway 프로젝트: `beneficial-celebration`, 환경 `production`, Postgres 서비스 이름 `Postgres`, 앱 서비스 `focused-benevolence`.
- 실제 서비스의 `DATABASE_URL`이나 Firebase 설정은 변경하지 않습니다.
- **Railway Pro 업그레이드 불필요**. 다만 Railway Trial 크레딧 소진/만료 시 예약 실행이 중단될 수 있습니다.
- R2는 **무료 사용량이 있지만 R2 구독 시작에 결제 수단이 필요할 수 있습니다**. 비용 사용량은 Cloudflare 계정에서 별도 확인하세요.
- GitHub에 DB 백업 파일, DB URL, R2 토큰, 암호화 키를 올리면 안 됩니다.

## A. Cloudflare R2 저장소 준비 (스마트폰 Chrome)
1. https://dash.cloudflare.com/ 열고 계정 생성/로그인.
2. 왼쪽 **Storage & databases → R2 → Overview**, R2 이용 활성화(필요한 결제 단계 확인).
3. **Create bucket** 누르고 `snu-studyroom-backups` 같은 고유한 이름으로 생성. **Standard** 선택. Public Development URL, 공개 도메인, R2.dev 공개 액세스는 **켜지 마세요**.
4. R2 → **Manage R2 API Tokens** → **Create API token**. `Object Read & Write` 권한을 **이 백업 버킷 한 개에만** 적용.
5. 아래 4가지를 안전하게 기록해 둡니다. 채팅/스크린샷에 공유하지 마세요: `R2_ENDPOINT` (`https://계정ID.r2.cloudflarestorage.com`), `R2_BUCKET`(버킷 이름), `R2_ACCESS_KEY_ID`, `R2_SECRET_ACCESS_KEY`. 마지막 두 값은 비밀번호 취급.
6. R2 버킷 → **Settings → Object Lifecycle Rules**에서, 복구가 확인된 뒤 30일~90일 보관 정책을 설정하는 것을 권장. 초기에는 자동 삭제를 바로 활성화하지 않아도 됩니다.

## B. Codespaces에 백업 작업 ZIP 준비
현재 v5.3 프로젝트를 삭제하지 마세요. `SNU_StudyRoom_PG_Backup_Worker.zip`을 Codespaces의 `/workspaces/studycafe/`로 업로드/가져오기(GitHub로 파일 업로드 시에는 ZIP만 올리고 풀기). 

```bash
cd /workspaces/studycafe
unzip -n SNU_StudyRoom_PG_Backup_Worker.zip
cd SNU_StudyRoom_PG_Backup_Worker
node --test tests/*.test.mjs
```

기존 Codespaces에서 Railway CLI 로그인을 했다면 그대로 재사용 가능합니다. 새 폴더에서 프로젝트 연결 후 **새 백업 전용 서비스**를 만듭니다.

```bash
railway link
# 프로젝트 beneficial-celebration, 환경 production 선택. 서비스는 선택 안 해도 됨.
railway add --service studyroom-pg-backup --json
```

> 백업 전용 서비스 `studyroom-pg-backup`이 생성된 경우에만 진행하세요. `Postgres`나 기존 `focused-benevolence` 서비스는 건드리지 마세요. `railway add` 성공 후 중복 실행하지 마세요.

## C. 백업 서비스 환경변수 등록
아래 CLI 명령은 **항상 `--service studyroom-pg-backup`**을 사용합니다. 비밀키는 터미널에 표시하지 않습니다.

```bash
railway variable set 'DATABASE_URL=${{Postgres.DATABASE_URL}}' --service studyroom-pg-backup --skip-deploys
railway variable set R2_BUCKET=snu-studyroom-backups --service studyroom-pg-backup --skip-deploys
```

`R2_BUCKET` 이름은 **실제로 만든 R2 버킷명으로 수정**하세요.

```bash
railway variable set 'R2_ENDPOINT=https://본인계정ID.r2.cloudflarestorage.com' --service studyroom-pg-backup --skip-deploys
```

R2 Access Key와 Secret Access Key는 코드·셸 명령 기록에 직접 쓰지 않도록 `read`로 입력할 수 있습니다:

```bash
read -rsp 'R2 Access Key ID: ' R2_ID; echo
printf '%s' "$R2_ID" | railway variable set R2_ACCESS_KEY_ID --stdin --service studyroom-pg-backup --skip-deploys
unset R2_ID
read -rsp 'R2 Secret Access Key: ' R2_SECRET; echo
printf '%s' "$R2_SECRET" | railway variable set R2_SECRET_ACCESS_KEY --stdin --service studyroom-pg-backup --skip-deploys
unset R2_SECRET
```

### 암호화 키 만들기 · 가장 중요

```bash
mkdir -p /home/codespace/.config/snu-studyroom
umask 077
openssl rand -base64 32 > /home/codespace/.config/snu-studyroom/backup-key.b64
chmod 600 /home/codespace/.config/snu-studyroom/backup-key.b64
railway variable set BACKUP_ENCRYPTION_KEY_B64 --stdin --service studyroom-pg-backup --skip-deploys < /home/codespace/.config/snu-studyroom/backup-key.b64
```

**이 암호화 키를 비밀번호 관리자 등 Codespaces·Railway 밖의 안전한 곳에도 반드시 한 번 복사해 보관하세요.** 키를 분실하면 R2에 저장한 백업을 복원할 수 없습니다. ChatGPT나 GitHub에 절대 보내지 마세요. 또한 기존 키가 있으면 `openssl rand ... >` 명령을 다시 실행하지 마세요. 키를 변경하면 이전 백업이 해독되지 않습니다.

## D. Railway Cron 일정 설정
Railway 대시보드 → 프로젝트 `beneficial-celebration` → `studyroom-pg-backup` → **Settings → Cron Schedule**에서:

```
0 19 * * *
```

이는 **UTC 19:00 = 한국시간 다음 날 새벽 04:00**에 매일 실행됩니다. Cron은 UTC이며 몇 분 정도 지연될 수 있습니다. 시작 명령은 Dockerfile의 `node backup.mjs`가 실행되도록 유지하세요. **웹사이트 서비스 `focused-benevolence`에는 cron을 설정하지 마세요.**

> 일 1회 백업은 최근 최대 약 24시간의 데이터가 복구 지점 이후에 누락될 수 있는 정책입니다. 더욱 자주 백업하려면 별도 결정이 필요합니다.

## E. 백업 전용 서버 배포
백업 서비스 Root Directory는 **빈 값 또는 `/`**을 유지합니다. 여기서는 CLI가 *현재 백업 폴더만 전송*하므로 웹사이트처럼 `/SNU_...`로 지정하면 경로 오류가 납니다.

```bash
cd /workspaces/studycafe/SNU_StudyRoom_PG_Backup_Worker
railway up --service studyroom-pg-backup
```

업로드 성공만으로 자동 백업이 완료된 것은 아닙니다. Cron 설정과 Variables 적용 상태를 Railway에서 확인하세요. Docker 이미지 빌드가 성공하는지도 확인해야 합니다.

## F. 바로 시험 실행 및 실제 백업 확인
Cron 일정이 저장되고 배포가 성공한 뒤:

```bash
railway cron run --service studyroom-pg-backup --yes
railway cron list --service studyroom-pg-backup
railway logs --service studyroom-pg-backup --latest --lines 50
```

**성공 기준**: 로그에 `[backup] SUCCESS uploaded and HEAD-verified ...` 가 있고, Cloudflare R2 버킷에 `studyroom-backups/v1/.../*.dump.enc` 파일이 실제로 존재해야 합니다. `EXITED` 상태는 작업 종료만 의미하므로 반드시 성공 로그와 R2 객체를 함께 확인하세요.

## G. 복구 시험(운영 DB에 직접 복원 금지)
1. R2에서 `.dump.enc` 파일 다운로드.
2. 안전한 별도 테스트 PC/컨테이너에서 **원래 암호화 키**를 `BACKUP_ENCRYPTION_KEY_B64` 환경변수로 제공한 뒤 다음 실행:

```bash
node decrypt.mjs backup.dump.enc backup.dump
pg_restore --list backup.dump
pg_restore --dbname="$TEST_DATABASE_URL" --no-owner --no-acl --exit-on-error backup.dump
```

3. `TEST_DATABASE_URL`은 **운영 DB가 아닌 새롭고 비어 있는 테스트 DB**여야 합니다. 운영 DB의 DATABASE_URL을 절대 넣지 마세요.
4. 날짜별 공부 기록·계정·친구 관계 테이블과 건수를 확인하세요. **복구 시험 전에는 완전한 백업 검증이 아닙니다.**

## 한계와 운영 체크
- 실행 일정은 Railway Trial 크레딧·배포 상태에 종속됩니다. 서비스가 정지되거나 크레딧이 소진되면 백업도 중단됩니다.
- Cloudflare 버킷 접근키는 읽기/쓰기가 가능하므로 R2 버킷에만 권한을 제한하세요. 중요한 시점 백업은 별도 수동 다운로드하거나 추가 보관소에 복사하세요.
- 백업은 `pg_dump` 기준 해당 DB의 논리적 스냅샷입니다. PostgreSQL 전체 클러스터 역할·물리적 복제·시점 복구(PITR)를 제공하지 않습니다.
- GitHub 저장소에 DB 연결정보나 `.dump.enc`/`.dump` 파일을 커밋하지 마세요. 암호화 파일이라고 해도 필요 없는 공개는 피하세요.
- R2 무료 제공량 안에서는 추가 저장비가 없을 수 있지만 별도 결제 계약 및 사용량에 따라 청구될 수 있습니다.
- 개인정보를 포함하므로 R2에 공개 웹 URL을 설정하지 마세요.

공식 문서:
- https://docs.railway.com/cron-jobs
- https://developers.cloudflare.com/r2/get-started/
- https://developers.cloudflare.com/r2/get-started/s3/
- https://developers.cloudflare.com/r2/buckets/object-lifecycles/
- https://www.postgresql.org/docs/current/app-pgdump.html
