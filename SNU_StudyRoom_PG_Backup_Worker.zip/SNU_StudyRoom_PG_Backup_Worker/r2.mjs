import { createReadStream } from 'node:fs';
import { stat } from 'node:fs/promises';
import { S3Client, HeadObjectCommand, ListObjectsV2Command } from '@aws-sdk/client-s3';
import { Upload } from '@aws-sdk/lib-storage';

export function getR2Config(env = process.env) {
  const required = ['R2_ENDPOINT', 'R2_BUCKET', 'R2_ACCESS_KEY_ID', 'R2_SECRET_ACCESS_KEY'];
  for (const key of required) if (!env[key]?.trim()) throw new Error(`Missing ${key}`);
  const url = new URL(env.R2_ENDPOINT);
  if (url.protocol !== 'https:' || url.username || url.password || url.pathname !== '/' || url.search || url.hash) {
    throw new Error('R2_ENDPOINT must be an HTTPS endpoint without a path or credentials');
  }
  if (!/^[a-z0-9][a-z0-9-]{1,61}[a-z0-9]$/.test(env.R2_BUCKET)) throw new Error('Invalid R2_BUCKET');
  return { bucket: env.R2_BUCKET, endpoint: url.origin, accessKey: env.R2_ACCESS_KEY_ID, secretKey: env.R2_SECRET_ACCESS_KEY };
}

export function makeClient(conf) {
  return new S3Client({
    region: 'auto', endpoint: conf.endpoint,
    credentials: { accessKeyId: conf.accessKey, secretAccessKey: conf.secretKey },
    forcePathStyle: true,
    maxAttempts: 3,
  });
}

export async function uploadAndVerify(client, bucket, key, filePath) {
  const size = (await stat(filePath)).size;
  if (size < 40) throw new Error('Encrypted file is unexpectedly small');
  await new Upload({
    client,
    params: { Bucket: bucket, Key: key, Body: createReadStream(filePath), ContentType: 'application/octet-stream' },
    queueSize: 2, partSize: 8 * 1024 * 1024, leavePartsOnError: false,
  }).done();
  const head = await client.send(new HeadObjectCommand({ Bucket: bucket, Key: key }));
  if (Number(head.ContentLength) !== size) throw new Error('R2 object length verification failed');
  return size;
}

export async function listRecent(client, bucket, prefix = 'studyroom-backups/') {
  const result = await client.send(new ListObjectsV2Command({ Bucket: bucket, Prefix: prefix, MaxKeys: 30 }));
  return (result.Contents ?? []).map(o => ({ key: o.Key, bytes: o.Size, lastModified: o.LastModified }));
}
