# SNU Library Inspired 3D Study Room v5

Google 계정 연동 · 친구 시스템 · 친구 일일 랭킹. **기존 v4 Three.js 도서관(88개 책상/352개 좌석), 동물 아바타 4종, NPC 8명, A* 이동/카메라, WebSocket 멀티플레이어, 실시간 채팅, 착석 타이머, 날짜별 기록 및 전체 랭킹을 유지한 확장판**입니다. 실제 서울대학교 공식 서비스가 아닌 **비공식 창작 프로젝트**입니다.

## 먼저 구분할 두 가지 작업

**본인이 Firebase Console에서 직접 해야 하는 일:** Firebase 프로젝트 생성 → Authentication의 Google 제공업체 활성화 → 웹 앱 등록 및 공개 설정값 복사 → Codespaces 접속 호스트를 **Authorized domains**에 등록 → 서버 전용 Admin 서비스 계정 인증 정보 준비. 자세한 스마트폰 작업은 **`FIREBASE_MOBILE_SETUP.md`** 참조.

**Codespaces에서 할 일:** ZIP 압축 해제 → v4 서버 중지 → **v4 DB와 게스트 인증키를 비파괴적으로 이전** → `npm install` → Firebase 비밀 정보를 Git에 노출하지 않도록 환경변수 설정 → `npm run check`, `npm test`, `npm start` → 실제 모바일 Google 로그인 점검.

Firebase를 아직 설정하지 않았다면 v5는 **게스트 모드로 실행**할 수 있습니다. Firebase 프로젝트가 없다고 해서 v4 기능을 사용하지 못하게 만들지 않았습니다.

## 1. 스마트폰 Codespaces 설치

기존 v4 서버 터미널은 휴지통(터미널 종료)으로 중지할 수 있습니다. DB 백업과 마이그레이션 전에 **반드시 v4 서버를 정지**하여 미저장 공부 시간을 먼저 디스크로 반영하세요.

```sh
# 저장소 루트로 이동. 실제 위치가 다르면 경로를 조정하세요.
cd /workspaces/studycafe
unzip SNU_3D_StudyRoom_v5_Full_Project.zip
cd SNU_3D_StudyRoom_v5
```

**v4에 실제 공부 기록이 있고 새 v5 폴더에 기존 v5 DB가 없다면**, 다음 이전 명령을 먼저 실행하세요.

```sh
node scripts/import-v4.mjs ../SNU_3D_StudyRoom_v4
```

스크립트는 v4 SQLite 파일의 **일관된 백업**을 생성하고 v5에 사본을 만듭니다. `private-backups/` 및 `data/`는 `.gitignore` 대상이며 ZIP에 포함하지 않습니다. **기존 v4 DB를 삭제하거나 직접 수정하지 않습니다.** 이미 v5 DB 또는 `.guest-secret`이 존재하면 안전을 위해 덮어쓰지 않고 중단합니다. 기록이 없다면 이전 명령을 생략할 수 있습니다.

설치·기본 테스트·실행:

```sh
npm install
npm run check
npm test
npm start
```

Firebase를 설정하기 전에도 게스트로 시작할 수 있습니다. 모바일에서 Codespaces의 **PORTS → 3000 → Open in Browser**를 열면 됩니다. PORTS에서 Public으로 변경한 주소는 외부에서도 열리므로 개인 개발 중에는 가능하면 Private로 유지하고, 친구와 테스트할 때만 잠시 Public으로 설정하세요.

**이전 파일 위치가 다르면** `pwd`, `ls`, `find .. -maxdepth 3 -name studyroom.sqlite`로 확인하세요. `find` 결과가 없다면 Codespaces에 실제 v4 런타임 DB가 없는 것입니다. ZIP 안의 백업 코드는 **실제 사용자의 공부 DB를 포함하지 않습니다.** 새 ZIP만으로 이전 기록을 자동 복구할 수 없습니다.

## 2. Firebase 설정 (스마트폰)

자세한 순서는 `FIREBASE_MOBILE_SETUP.md`에 있습니다. 콘솔에서 가져올 값은 다음과 같습니다.

- **Firebase 웹 앱 설정(공개):** `apiKey`, `authDomain`, `projectId`, `appId`. 브라우저 앱에서 Firebase SDK 초기화에 사용됩니다. 서비스 계정 키가 아니며 본인 프로젝트에서 직접 가져와야 합니다.
- **서버 전용 설정(비공개):** Firebase `FIREBASE_PROJECT_ID`, Admin SDK의 Application Default Credentials(`GOOGLE_APPLICATION_CREDENTIALS`가 가리키는 서비스 계정 JSON 경로). JSON 내용은 클라이언트·Git·ZIP에 넣지 않습니다.
- **Codespaces 승인 도메인:** 예: `example-3000.app.github.dev`(개인의 실제 호스트). Firebase Authentication → Settings → Authorized domains. 호스트를 그대로 등록하고 경로, 프로토콜, 포트번호를 임의로 붙이지 않습니다.

실제 값 확보 후:

```sh
cp .env.example .env
```

`.env`를 Codespaces 편집기에서 수정하세요. `.env`는 Git 추적에서 제외합니다. `npm start`는 `node --env-file-if-exists=.env`로 값을 읽습니다. **실제 비밀 정보가 들어간 `.env`를 GitHub 저장소에 올리면 안 됩니다.** 서버 전용 JSON 파일은 저장소 밖 비공개 경로로 이동해야 합니다. Google 로그인이 작동하려면 `npm install`로 **공식 `firebase-admin`** 의존성을 설치해야 합니다.

`FIREBASE_WEB_CONFIG` 예시 형식(반드시 자신의 프로젝트 공개 값으로 교체):

```dotenv
FIREBASE_WEB_CONFIG='{"apiKey":"...","authDomain":"your-project.firebaseapp.com","projectId":"your-project","appId":"1:...:web:..."}'
```

Codespaces 모바일에서는 Google 계정 선택 팝업을 기본으로 사용합니다. 팝업을 차단하면 로그인에 실패합니다. Firebase 기본 리디렉션은 서드파티 저장소 제한으로 Codespaces에서 실패할 수 있어 자동 대체로 사용하지 않습니다. **실제 로그인 성공은 제공된 Firebase 프로젝트와 스마트폰에서 직접 확인해야 합니다.**

## 3. v4 데이터·인증키 보호 및 복구

v4 공부 기록은 `v4/data/studyroom.sqlite`(SQLite WAL 모드)에 있습니다. v4 게스트 토큰 서명키는 `v4/.guest-secret`이며 서버를 재시작해도 **같은 비밀키**를 사용해야 같은 게스트를 알아봅니다. v4가 `STUDYROOM_SECRET` 환경변수를 사용했다면 v5도 그 **동일한 값**을 안전하게 제공하세요.

**권장 이전:** v4 서버 종료 → `node scripts/import-v4.mjs ../SNU_3D_StudyRoom_v4` → DB 백업 경로 확인 → `npm start` → 내 기록의 날짜와 공부 시간 대조. 앱은 `migrations/002_sqlite.sql`의 새 테이블만 자동 생성합니다. 원본 `guests`, `study_daily` 기록은 그대로 유지합니다.

이전 후 서버 시작 전 DB를 다른 곳에 추가 백업하려면, 서버 종료 상태에서 다음 명령을 이용할 수 있습니다.

```sh
mkdir -p private-backups/manual
cp data/studyroom.sqlite private-backups/manual/studyroom.sqlite
cp .guest-secret private-backups/manual/.guest-secret
chmod 600 private-backups/manual/.guest-secret
```

위 `cp` 방식은 **서버를 정지하고 SQLite 연결이 닫힌 상태에만** 사용하세요. 운영 중에는 SQLite 백업 API를 이용해야 합니다. 데이터 마이그레이션이 실패하면 서버를 중지하고 기존 비공개 백업 파일을 원래 DB 경로로 복구한 뒤 다시 시도합니다. 복구 시 최신 DB를 먼저 별도로 보관하고 **절대로 백업을 무조건 덮어쓰지 마세요.** Github Codespaces 자체 삭제 시 로컬 DB와 비밀키가 유실될 수 있으므로 개인 비공개 저장소(공개 Git이 아닌 암호화 백업 또는 신뢰할 수 있는 비공개 저장소)에 보관해야 합니다.

**주의:** 구글 로그인 후 계정에 연결된 원래 게스트 서명 토큰은 재사용할 수 없도록 비활성화됩니다. 기존 브라우저의 게스트 토큰을 **일회성 연결 소유권 증명**으로 사용합니다. 로그인 시 현재 게스트가 아직 실제로 공부 중이면 서버가 먼저 공부 시간을 DB에 저장하고 착석 상태를 해제합니다. 계정이 이미 존재하면 기존 계정 내부 ID로 게스트 날짜별 기록을 더합니다(트랜잭션). 한 번 병합된 게스트 ID는 다시 병합되지 않습니다. **게스트 시절 동일 공부 세션이 두 독립 게스트 ID에 중복 기록되어 있는 경우까지 자동 검출하는 기능은 없습니다.** 계정 연결 실패 시 기존 기록이 수정되지 않도록 처리합니다.

## 4. 기능 및 UI

- **계정:** 처음 방문 시 Google 또는 게스트 중 선택. 기존 캐릭터 선택 모달 그대로 유지. 도서관 상단 계정 버튼을 눌러 Google 연결/로그아웃/스터디룸 데이터 삭제. Google 닉네임이 아닌 기존 도서관 닉네임을 사용합니다.
- **게스트:** v4 기록·이동·착석·채팅·전체 공개 랭킹을 그대로 사용합니다. 토큰은 브라우저에 종속됩니다.
- **Google 로그인:** Admin SDK가 Google 공급자의 Firebase ID 토큰을 프로젝트·발급자·만료·서명·폐기 상태와 함께 검증합니다. 앱 쿠키는 HttpOnly·SameSite=Lax이며 HTTPS에서는 Secure입니다. 서버 세션은 14일 유효, 해시 저장, 로그아웃 시 폐기. 상태 변경 API는 서버 CSRF 토큰도 검사합니다.
- **친구:** 친구 코드 검색 → 신청 → 상대방 수락 → 친구 목록. 신청 취소/거절, 친구 삭제, 차단 및 해제. 목록 상태는 약 30초 주기와 탭 복귀 때 확인합니다.
- **프라이버시:** 전체 랭킹 참여 설정(v4)과 친구 랭킹 참여, 친구에게 온라인·공부 상태 공개, 합류 허용은 각각 별도 설정입니다. 차단 관계는 친구 정보 API와 합류 기능에서 제외됩니다.
- **친구 합류:** 친구가 접속한 방의 ID를 서버가 검증한 다음 초대와 좌석 후보 4개를 제공합니다. 실제 의자 선택·충돌·NPC 좌석 금지는 기존 v4 서버 로직이 검증합니다. `POST /api/rooms/private`로 생성된 비공개 방에는 승인된 계정만 접근할 수 있습니다. 단, 기존 `?room=main` 같은 일반 방은 초대 링크를 아는 게스트도 들어올 수 있는 **공개 방**입니다.
- **친구 랭킹:** 본인과 공개를 허용한 친구의 한국시간 당일 공부 시간. NPC와 차단 관계 제외. 동점 시 v4와 동일하게 내부 ID 순서. 별도 30초 갱신. 전체 랭킹 유지.
- **동일 계정 여러 기기:** 기록·친구 API 조회는 여러 기기에서 허용, 서버의 실제 3D 공부 제어권은 계정당 하나만 허용. 둘째 기기에서 접속하면 이전 기기의 제어권을 이전할지 확인하며, 동의하면 기존 접속을 종료·전환합니다. 서버에서 공부 시간을 중복 적립하지 않습니다. 서버 재시작 시 실시간 자리/방 상태는 초기화되지만 DB 기록은 남습니다.
- **회원 탈퇴:** 스터디룸 앱 측 공부 기록, 친구 데이터, 세션 및 Firebase UID 연결을 삭제합니다. **Google 계정 자체나 Firebase Authentication 제공업체 사용자 계정을 삭제하지 않습니다.** 재로그인 시 새 내부 계정이 생성될 수 있습니다. Firebase 사용자 항목까지 삭제해야 하는 운영 정책은 별도 관리자 절차가 필요합니다.
- **기존 UI:** 기존 Three.js 3D 씬/기하/카메라/물리적 가구는 다시 작성하지 않았습니다. 새 `친구` 패널과 계정 다이얼로그만 추가했습니다. `커뮤니티`는 여전히 준비 중입니다. 패널을 전환해도 서버 기준 공부 시간이 임의로 정지되지 않습니다.

## 5. 서버·마이그레이션 구조

| 경로 | 책임 |
|---|---|
| `index.html` | v4 3D 씬 + 계정/친구 패널 UI 연결 |
| `client/network.js`, `client/dashboard.js` | v4 네트워크/내 기록/전체 랭킹 확장 |
| `client/account.js` | 공식 Firebase Web SDK 선택적 Google 인증 |
| `client/friends.js` | 반응형 친구/친구 랭킹 패널 |
| `server/firebase.js` | Firebase Admin `verifyIdToken(token, true)` |
| `server/account-api.js` | HttpOnly 앱 세션, CSRF, 친구 API, 합류 권한 |
| `server/accounts-store.js` | SQLite v5 비파괴 스키마·친구/계정·트랜잭션 |
| `server/index.js`, `server/room.js` | v4 HTTP/WebSocket/공부 타이머 + 계정 접근 검증 |
| `migrations/001_sqlite.sql`, `002_sqlite.sql` | 기존 v4 테이블 + v5 추가 테이블 |
| `scripts/import-v4.mjs` | 원본을 손대지 않는 v4 백업/이전 |
| `backup_v4/` | v4 원본 소스코드 백업, 비밀키/런타임 DB 제외 |

### PostgreSQL 현황 (중요)

v4에 기본 PostgreSQL 어댑터(`server/store.js`, `migrations/001_postgres.sql`)가 있었으나 v5의 계정/친구/세션·트랜잭션 스키마는 **SQLite에만 구현**되어 있습니다. `DATABASE_URL`을 설정해 v5로 실행하면 오류로 중단하며, PostgreSQL에서 v5 기능이 동작한다고 주장하지 않습니다. 운영용 PostgreSQL 마이그레이션/어댑터 구현과 실제 연결 테스트는 후속 단계입니다. 기존 v4 PostgreSQL 인스턴스와 데이터를 **v5의 SQLite로 자동 이전하지 않습니다.**

### 배포와 24시간 운영

Codespaces는 개발/테스트용이며 24시간 가용성을 보장하는 운영 서비스가 아닙니다. 운영 단계에서는 HTTPS 고정 도메인, 보안 관리형 DB, 백업, Firebase 승인 도메인, 서비스 계정 비밀 관리, 분산 실시간 좌석 잠금, 서버 모니터링이 별도로 필요합니다. **현재 v5는 단일 Node.js 프로세스의 방/좌석 서버**입니다. 영구 SQLite와 함께 동일 파일시스템에서 단일 인스턴스로 실행해야 하며 여러 프로세스/서버에서 좌석 상태가 공유되지는 않습니다.

## 6. 자동 테스트와 검증 범위

```sh
npm run check
npm test
```

`TEST_REPORT.md`와 `test-results.txt`, `check-results.txt`를 함께 제공합니다. v4 기존 테스트 11개 및 신규 SQLite/친구/모의 Firebase API/실제 TCP-WebSocket 인증 테스트를 수행했습니다.

**직접 검증한 범위:** Node.js 테스트 환경의 SQLite 파일·트랜잭션, 서버 API·CSRF·재접속·실제 WebSocket 프레임/좌석 검사, v4 데이터 복사 스크립트. **검증하지 못한 범위:** Firebase 실제 프로젝트를 이용한 OAuth 팝업·Admin 인증 정보 연결, 스마트폰 WebGL 렌더링·터치, Android/iOS 브라우저 로그인 제약, 장시간/고부하, v5 PostgreSQL(미구현). 실제 사용자 DB·Firebase 프로젝트가 이 ZIP에 들어 있지 않으므로, 사용자 기기에서 직접 검증해야 합니다.

> [Firebase Google 로그인 공식 문서](https://firebase.google.com/docs/auth/web/google-signin) · [Firebase 리디렉션 제한](https://firebase.google.com/docs/auth/web/redirect-best-practices) · [Admin 서버 토큰 검증](https://firebase.google.com/docs/auth/admin/verify-id-tokens)
